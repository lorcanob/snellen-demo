"""Shared look and helpers for the Snellen screening toy's pygame screens.

Holds the colour palette, the type aliases used for injectable event
sources and clocks (so screens can be driven by tests without a real window), and
helpers for drawing text pages.
"""

from collections.abc import Callable, Iterable, Sequence

import pygame

BACKGROUND = (250, 250, 247)
"""Page background: an off-white that is easy on the eyes and gives high contrast."""

TEXT = (20, 20, 20)
"""Main text and optotypes: near-black."""

MUTED = (110, 110, 110)
"""Secondary text and unselected bars."""

ACCENT = (40, 110, 200)
"""Highlights: progress, success, the selected bar, the current-letter marker."""

ERROR = (190, 40, 40)
"""Failures and warnings."""


Events = Callable[[], Iterable[pygame.event.Event]]
"""A function returning pending events, like ``pygame.event.get`` (scripted in tests)."""

Tick = Callable[[], object]
"""A function called once per frame to pace a screen's loop."""


def frame_clock(tick: Tick | None) -> Tick:
    """The tick function a screen's loop should call once per frame.

    Parameters
    ----------
    tick : callable or None
        A tick supplied by the caller (tests pass ``lambda: None`` to run flat out).

    Returns
    -------
    callable
        ``tick`` itself, or, if it is ``None``, a function that holds the loop to 30
        frames per second.
    """
    if tick is not None:
        return tick
    clock = pygame.time.Clock()
    return lambda: clock.tick(30)


def is_quit(event: pygame.event.Event) -> bool:
    """Whether an event asks to leave: the window was closed or Esc was pressed.

    Parameters
    ----------
    event : pygame.event.Event
        Any pygame event.

    Returns
    -------
    bool
    """
    return event.type == pygame.QUIT or (
        event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE
    )


def key_name(event: pygame.event.Event) -> str:
    """The name a ``...Step`` expects for a key press: ``"space"``, ``"up"``, ``"c"``, ``"1"``.

    Parameters
    ----------
    event : pygame.event.Event
        A ``KEYDOWN`` event.

    Returns
    -------
    str
        ``pygame.key.name`` of the key: lower-case letters and digits, ``"up"``,
        ``"down"``, ``"left"``, ``"right"``, ``"space"``, ``"return"``, ``"backspace"``...
    """
    return pygame.key.name(event.key)


def wrap_text(text: str, font: pygame.font.Font, max_width_px: int) -> list[str]:
    """Split text at spaces so each rendered line fits a width.

    Parameters
    ----------
    text : str
        The text to wrap.
    font : pygame.font.Font
        The font it will be rendered in.
    max_width_px : int
        Widest a rendered line may be.

    Returns
    -------
    list of str
        One or more lines. A single word wider than ``max_width_px`` is left on its own
        line rather than broken.
    """
    if font.size(text)[0] <= max_width_px:
        return [text]
    lines, current = [], ""
    for word in text.split():
        candidate = f"{current} {word}" if current else word
        if current and font.size(candidate)[0] > max_width_px:
            lines.append(current)
            current = word
        else:
            current = candidate
    return lines + [current]


def draw_text_page(
    surface: pygame.Surface,
    title: str,
    lines: Sequence[str],
    colours: Sequence[tuple[int, int, int]],
) -> int:
    """Draw a full page of text: background, title and wrapped body lines.

    Parameters
    ----------
    surface : pygame.Surface
        Where to draw.
    title : str
        Heading, drawn large.
    lines : sequence of str
        Body lines, each wrapped to fit inside the margins.
    colours : sequence of tuple of int
        One RGB colour per body line.

    Returns
    -------
    int
        The y coordinate just below the last line, for drawing anything that follows
        (such as a progress bar).

    Raises
    ------
    ValueError
        If ``lines`` and ``colours`` have different lengths.
    """
    # Fonts are loaded per call: caching them across pygame.quit() leaves dead handles.
    title_font, body_font = pygame.font.Font(None, 56), pygame.font.Font(None, 32)
    surface.fill(BACKGROUND)
    margin = surface.get_width() // 12
    y = surface.get_height() // 6
    rendered = title_font.render(title, True, TEXT)
    surface.blit(rendered, (margin, y))
    y += rendered.get_height() + 30
    max_width_px = surface.get_width() - 2 * margin
    for line, colour in zip(lines, colours, strict=True):
        for part in wrap_text(line, body_font, max_width_px):
            text = body_font.render(part, True, colour)
            surface.blit(text, (margin, y))
            y += text.get_height() + 12
    return y
