"""Optotypes for the Snellen screening toy: what each chart type is and how it's answered.

An optotype is a shape shown on the chart (a Tumbling E, a letter...). Each kind
implements the :class:`Optotype` interface: a name, its possible symbols, a sentence on
how to answer, and which key answers which symbol. The eye test step
(:mod:`snellen.steps.chart`) and the scoring (:mod:`snellen.acuity`) only use that
interface, so a new kind needs no changes elsewhere.

How each kind is *drawn* is separate: :mod:`snellen.optotype_drawing` draws them with
pygame for the desktop app. This module has no pygame, so a browser front end can
share it.

Available kinds:

* :class:`SnellenLetters`: the classic Snellen chart letters C D E F L O P T Z, typed.
* :class:`TumblingE`: an E pointing up, down, left or right; answered with the arrow
  keys.
* :class:`LandoltC`: a ring with a gap at the top, bottom, left or right (ISO 8596);
  answered with the arrow keys.

Keys are given by name, as :func:`snellen.ui.key_name` reports them: ``"up"``,
``"down"``, ``"left"``, ``"right"``, and lower-case letters such as ``"c"``.

This is a screening toy, not a diagnostic tool.
"""

from typing import Protocol

from snellen.acuity import Symbol
from snellen.geometry import Direction

SNELLEN_LETTERS = ("C", "D", "E", "F", "L", "O", "P", "T", "Z")
"""The letters of Snellen's original chart."""

KEY_DIRECTIONS = {
    "up": Direction.UP,
    "down": Direction.DOWN,
    "left": Direction.LEFT,
    "right": Direction.RIGHT,
}
"""Arrow key name to the direction it answers (for the E and the Landolt C)."""


class Optotype(Protocol):
    """What the eye test needs from a kind of optotype.

    Attributes
    ----------
    name : str
        Shown to the user when choosing a chart, such as ``"Snellen letters"``.
    symbols : tuple of Symbol
        Everything one optotype can be; passed to :class:`snellen.acuity.AcuityTest`.
    how_to_answer : str
        One sentence for the instructions, such as which keys to press.
    """

    name: str
    symbols: tuple[Symbol, ...]
    how_to_answer: str

    def symbol_for_key(self, key: str) -> Symbol | None:
        """The answer a key press gives, or ``None`` if the key isn't an answer.

        Parameters
        ----------
        key : str
            The key's name, such as ``"up"`` or ``"c"``.

        Returns
        -------
        Symbol or None
        """
        ...


class TumblingE:
    """The Tumbling E: an E pointing up, down, left or right, answered with the arrow keys.

    Every stroke and gap is exactly a fifth of the height
    (:func:`snellen.geometry.tumbling_e_cells`). Suits anyone, including people who
    don't read the Latin alphabet.
    """

    name = "Tumbling E"
    symbols: tuple[Symbol, ...] = tuple(Direction)
    how_to_answer = (
        "Every E points up, down, left or right: press that arrow key, or SPACE if you can't tell."
    )

    def symbol_for_key(self, key: str) -> Symbol | None:
        """The arrow keys answer; everything else is ignored."""
        return KEY_DIRECTIONS.get(key)


class SnellenLetters:
    """Classic Snellen chart letters, answered by typing them.

    Parameters
    ----------
    letters : sequence of str, optional
        Capital letters to use; :data:`SNELLEN_LETTERS` by default. At least five, so a
        line never repeats a letter.

    Raises
    ------
    ValueError
        If a letter isn't a single capital A-Z.
    """

    name = "Snellen letters"
    how_to_answer = "Type each letter you see, or press SPACE if you can't tell."

    def __init__(self, letters: tuple[str, ...] = SNELLEN_LETTERS) -> None:
        """Check and keep the letters; see the class docstring."""
        for letter in letters:
            if len(letter) != 1 or not "A" <= letter <= "Z":
                raise ValueError(f"letters must be single capitals A-Z, got {letter!r}")
        self.symbols: tuple[Symbol, ...] = tuple(letters)

    def symbol_for_key(self, key: str) -> Symbol | None:
        """A letter key answers that letter (if it's on this chart); others are ignored."""
        letter = key.upper()
        return letter if len(key) == 1 and letter in self.symbols else None


class LandoltC:
    """The Landolt C: a ring with a gap at the top, bottom, left or right.

    The standard optotype for clinical and research acuity (ISO 8596): the ring's outer
    diameter is the optotype height, and both the ring and the gap are a fifth of it, on
    the same 5 x 5 grid as the Tumbling E (:data:`snellen.geometry.LANDOLT_C_RADII`,
    :func:`snellen.geometry.landolt_c_gap`). Answered with the arrow keys, so it suits
    anyone, whatever alphabet they read.
    """

    name = "Landolt C"
    symbols: tuple[Symbol, ...] = tuple(Direction)
    how_to_answer = (
        "Each ring has a gap at the top, bottom, left or right: press that arrow key, "
        "or SPACE if you can't tell."
    )

    def symbol_for_key(self, key: str) -> Symbol | None:
        """The arrow keys answer; everything else is ignored."""
        return KEY_DIRECTIONS.get(key)


def available_optotypes() -> list[Optotype]:
    """The chart types the user can choose from, in the order they're offered.

    Returns
    -------
    list of Optotype
        Fresh instances: Snellen letters, Tumbling E, then Landolt C.
    """
    return [SnellenLetters(), TumblingE(), LandoltC()]
