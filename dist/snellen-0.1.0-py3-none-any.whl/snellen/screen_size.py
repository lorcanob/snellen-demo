"""Screen pixel density for the Snellen screening toy: from the hardware, or saved from an
earlier card measurement.

This module only does I/O; the maths is in :mod:`snellen.geometry`.

Densities are in pygame *window* pixels per mm, which is what letter sizes are drawn
in. On macOS, pygame works in points (logical pixels) by default, not physical Retina
pixels, and CoreGraphics' pixel width reports points too, so the two agree.

Saved measurements
------------------
A card measurement is saved to ``~/.config/snellen/screens.json`` (override with the
``SNELLEN_SCREEN_FILE`` environment variable). It is keyed by the desktop size, such
as ``"1512x982"``, so each display or resolution keeps its own value.
"""

import ctypes
import ctypes.util
import json
import os
import sys
from collections.abc import Callable
from dataclasses import asdict
from pathlib import Path

from snellen.geometry import PLAUSIBLE_PX_PER_MM, px_per_mm_from_display
from snellen.measurements import ScreenRecord

DEFAULT_CACHE_PATH = Path.home() / ".config" / "snellen" / "screens.json"
"""Where card measurements are saved unless ``SNELLEN_SCREEN_FILE`` says otherwise."""

DisplayReport = tuple[float, float]
"""(width in window pixels, width in mm) of the main display."""


class _CGSize(ctypes.Structure):
    """ctypes mirror of CoreGraphics' ``CGSize`` struct (width and height as doubles)."""

    _fields_ = [("width", ctypes.c_double), ("height", ctypes.c_double)]


def core_graphics_display() -> DisplayReport | None:
    """The main display's width in points and in mm, from macOS CoreGraphics.

    Returns
    -------
    tuple of float or None
        ``(width_px, width_mm)``, or ``None`` when not on macOS or CoreGraphics can't be
        loaded. External monitors that don't report a size give ``width_mm == 0``.
    """
    if sys.platform != "darwin":
        return None
    library = ctypes.util.find_library("CoreGraphics")
    if library is None:
        return None
    cg = ctypes.CDLL(library)
    cg.CGMainDisplayID.restype = ctypes.c_uint32
    cg.CGDisplayScreenSize.restype = _CGSize
    cg.CGDisplayScreenSize.argtypes = [ctypes.c_uint32]
    cg.CGDisplayPixelsWide.restype = ctypes.c_size_t
    cg.CGDisplayPixelsWide.argtypes = [ctypes.c_uint32]
    display = cg.CGMainDisplayID()
    return float(cg.CGDisplayPixelsWide(display)), cg.CGDisplayScreenSize(display).width


def hardware_px_per_mm(
    read_display: Callable[[], DisplayReport | None] = core_graphics_display,
) -> float | None:
    """Screen density reported by the hardware, if it can be trusted.

    Parameters
    ----------
    read_display : callable, optional
        Returns ``(width_px, width_mm)`` or ``None``; :func:`core_graphics_display` by
        default (tests pass a fake).

    Returns
    -------
    float or None
        Pixels per mm, or ``None`` if the size is unknown, the lookup failed, or the
        result is implausible (:data:`snellen.geometry.PLAUSIBLE_PX_PER_MM`).
    """
    try:
        report = read_display()
        return None if report is None else px_per_mm_from_display(*report)
    except (OSError, AttributeError, ValueError):
        return None


def desktop_key(size_px: tuple[int, int]) -> str:
    """The cache key for a display, from its desktop size.

    Parameters
    ----------
    size_px : tuple of int
        ``(width, height)``, for example from ``pygame.display.get_desktop_sizes()[0]``.

    Returns
    -------
    str

    Examples
    --------
    >>> desktop_key((1512, 982))
    '1512x982'
    """
    return f"{size_px[0]}x{size_px[1]}"


def cache_path() -> Path:
    """Where screen densities are saved.

    Returns
    -------
    pathlib.Path
        ``$SNELLEN_SCREEN_FILE`` if set, else ``~/.config/snellen/screens.json``.
    """
    return Path(os.environ.get("SNELLEN_SCREEN_FILE", DEFAULT_CACHE_PATH))


def _read_all(path: Path) -> dict:
    """All saved entries; an empty dict if the file is missing, unreadable or not an object."""
    try:
        data = json.loads(path.read_text())
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def load_cached(key: str, path: Path) -> ScreenRecord | None:
    """The saved density for one display.

    Parameters
    ----------
    key : str
        Display key from :func:`desktop_key`.
    path : pathlib.Path
        The cache file.

    Returns
    -------
    ScreenRecord or None
        The saved record, or ``None`` if it is missing, malformed or implausible. A
        broken file never stops the app; the user is just asked to measure again.
    """
    entry = _read_all(path).get(key)
    try:
        record = ScreenRecord(float(entry["px_per_mm"]), str(entry.get("source", "card")))
    except (TypeError, KeyError, ValueError):
        return None
    low, high = PLAUSIBLE_PX_PER_MM
    return record if low <= record.px_per_mm <= high else None


def save_cached(key: str, record: ScreenRecord, path: Path) -> None:
    """Save the density for one display, keeping other displays' entries.

    Parameters
    ----------
    key : str
        Display key from :func:`desktop_key`.
    record : ScreenRecord
        What to save.
    path : pathlib.Path
        The cache file; its folder is created if needed. A broken file is replaced.
    """
    data = _read_all(path)
    data[key] = asdict(record)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2))
