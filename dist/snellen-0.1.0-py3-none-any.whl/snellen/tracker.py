"""Camera and face model for the Snellen screening toy.

Opens the webcam and MediaPipe's face landmarker, and turns each frame into plain pixel
numbers (a :class:`~snellen.measurements.Reading`):

* the bank card's width, found by :func:`snellen.card.find_card` (used during
  calibration);
* the pupil distance and one-eye face spans, from the face-mesh landmarks through
  :mod:`snellen.face`.

It does no distance or acuity maths and draws nothing. Callers turn these numbers into
millimetres and distances with :mod:`snellen.geometry`. This is the only module that
needs MediaPipe; the measurement code it calls doesn't, so that code can also run in a
browser.

This is a screening toy, not a diagnostic tool.
"""

import time
from collections.abc import Callable
from pathlib import Path
from typing import Any, Protocol, Self

import cv2
import mediapipe as mp
import numpy as np
from mediapipe.tasks.python import BaseOptions
from mediapipe.tasks.python.vision import FaceLandmarker, FaceLandmarkerOptions

from snellen.card import find_card
from snellen.face import eye_spans_px, pupils_px
from snellen.measurements import Detection, Reading


class Capture(Protocol):
    """Interface for a video source: the parts of ``cv2.VideoCapture`` the tracker uses."""

    def read(self) -> tuple[bool, np.ndarray | None]:
        """Grab the next frame.

        Returns
        -------
        tuple
            ``(ok, frame)``: whether a frame came, and the BGR ``numpy`` array or ``None``.
        """
        ...

    def release(self) -> None:
        """Free the device."""
        ...


class CameraDevice(Capture, Protocol):
    """A :class:`Capture` that can also say whether it opened (``isOpened``), like a webcam."""

    def isOpened(self) -> bool:
        """Whether the device opened (it may still deliver no frames)."""
        ...


class CameraUnavailable(RuntimeError):
    """The camera could not be opened or gave no picture.

    The message explains the likely fixes (macOS camera permission, choosing a different
    camera with ``SNELLEN_CAMERA_INDEX``) and is meant to be shown to the user as-is.
    """


CAMERA_RETRY_S = 0.5
"""Seconds between attempts to open the camera while waiting for permission."""


def open_camera(
    camera_index: int,
    *,
    timeout_s: float = 30.0,
    open_capture: Callable[[int], CameraDevice] = cv2.VideoCapture,
    sleep: Callable[[float], None] = time.sleep,
    now: Callable[[], float] = time.monotonic,
) -> CameraDevice:
    """Open a camera that is delivering frames, retrying until ``timeout_s`` runs out.

    On macOS, OpenCV fails the first open while the camera-permission prompt is showing,
    and that capture never recovers. A fresh capture picks up the permission once it has
    been granted, so this keeps creating new ones.

    Parameters
    ----------
    camera_index : int
        OpenCV camera number; 0 is usually the built-in webcam.
    timeout_s : float, optional
        Seconds to keep trying. Default 30.
    open_capture : callable, optional
        Factory for captures, ``cv2.VideoCapture`` by default (replaceable in tests).
    sleep : callable, optional
        Waits between attempts, ``time.sleep`` by default.
    now : callable, optional
        Monotonic clock in seconds, ``time.monotonic`` by default.

    Returns
    -------
    CameraDevice
        An open capture that has already delivered one frame.

    Raises
    ------
    CameraUnavailable
        If no attempt gave a picture before the timeout.
    """
    deadline = now() + timeout_s
    while True:
        capture = open_capture(camera_index)
        if capture.isOpened() and capture.read()[0]:
            return capture
        capture.release()
        if now() >= deadline:
            raise CameraUnavailable(
                f"Camera {camera_index} gave no picture after {timeout_s:.0f} s.\n"
                "  - macOS: System Settings > Privacy & Security > Camera, and allow the app\n"
                "    you ran this from (Terminal, iTerm, VS Code...), then run again.\n"
                "  - If it never asked: run `tccutil reset Camera` and run again.\n"
                "  - Wrong camera? Set SNELLEN_CAMERA_INDEX=1 (or 2...); index 0 can be\n"
                "    an iPhone Continuity Camera."
            )
        sleep(CAMERA_RETRY_S)


class Landmarker(Protocol):
    """Interface for a face landmarker: the parts of MediaPipe's ``FaceLandmarker`` used here."""

    def detect(self, image: mp.Image) -> Any:
        """Find faces in an RGB image.

        Parameters
        ----------
        image : mediapipe.Image
            The frame, in RGB.

        Returns
        -------
        object
            A result whose ``face_landmarks`` is a list of faces, each a list of landmarks
            with ``x`` and ``y`` normalised to 0..1 across the image.
        """
        ...

    def close(self) -> None:
        """Free the model."""
        ...


def open_landmarker(model_path: Path | str) -> FaceLandmarker:
    """Create a single-face MediaPipe face landmarker.

    Parameters
    ----------
    model_path : pathlib.Path or str
        Path to the ``face_landmarker.task`` model file.

    Returns
    -------
    mediapipe.tasks.python.vision.FaceLandmarker
        A landmarker that finds at most one face, with iris landmarks.
    """
    options = FaceLandmarkerOptions(
        base_options=BaseOptions(model_asset_path=str(model_path)), num_faces=1
    )
    return FaceLandmarker.create_from_options(options)


class Tracker:
    """Reads camera frames and measures the card, pupils and face spans in each.

    Use it as a context manager so the camera is always released:

        with Tracker.open(0, "models/face_landmarker.task") as tracker:
            reading = tracker.read()

    Parameters
    ----------
    capture : Capture
        The video source.
    landmarker : Landmarker
        The face model.

    See Also
    --------
    Tracker.open : open the webcam and model together.
    """

    def __init__(self, capture: Capture, landmarker: Landmarker) -> None:
        """Wrap an open capture and landmarker; see the class docstring."""
        self._capture = capture
        self._landmarker = landmarker

    @classmethod
    def open(cls, camera_index: int, model_path: Path | str) -> Self:
        """Open a webcam and the face landmarker.

        Parameters
        ----------
        camera_index : int
            OpenCV camera number (0 is usually the built-in webcam).
        model_path : pathlib.Path or str
            Path to the ``face_landmarker.task`` model file.

        Returns
        -------
        Tracker
            A ready tracker. If loading the model fails, the camera is released before the
            error propagates.

        Raises
        ------
        CameraUnavailable
            If the camera gave no picture (see :func:`open_camera`).
        """
        capture = open_camera(camera_index)
        try:
            landmarker = open_landmarker(model_path)
        except Exception:
            capture.release()
            raise
        return cls(capture, landmarker)

    def grab(self) -> np.ndarray | None:
        """The next camera frame.

        Returns
        -------
        numpy.ndarray or None
            BGR frame, or ``None`` if the camera returned none.
        """
        ok, frame = self._capture.read()
        return frame if ok and frame is not None else None

    def detect(self, frame_bgr: np.ndarray) -> Detection:
        """Find the card, pupils and one-eye spans in a frame.

        Parameters
        ----------
        frame_bgr : numpy.ndarray
            BGR frame, for example from :meth:`grab`.

        Returns
        -------
        Detection
            What was found; the card search uses the pupils, if found, to look only on the
            forehead.
        """
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        result = self._landmarker.detect(mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb))
        pupils = spans = None
        if result.face_landmarks:
            h, w = frame_bgr.shape[:2]
            pupils = pupils_px(result.face_landmarks[0], w, h)
            spans = eye_spans_px(result.face_landmarks[0], w, h)
        return Detection(card=find_card(frame_bgr, pupils), pupils_px=pupils, spans=spans)

    def read(self) -> Reading | None:
        """Grab and measure the next frame.

        Returns
        -------
        Reading or None
            The frame's measurements, or ``None`` if the camera returned no frame.
        """
        frame = self.grab()
        return None if frame is None else self.detect(frame).reading()

    def close(self) -> None:
        """Release the camera and the face model."""
        self._capture.release()
        self._landmarker.close()

    def __enter__(self) -> Self:
        """Return the tracker itself, for use in a ``with`` block."""
        return self

    def __exit__(self, *exc: object) -> None:
        """Release the camera and model when the ``with`` block ends, even on error."""
        self.close()
