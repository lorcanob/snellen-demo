"""Staircase scoring for the Snellen screening toy, for any optotype.

Pure logic: no pygame, no camera, no I/O. One :class:`AcuityTest` scores one eye. It
doesn't care what the optotypes look like, only which symbols they can be: the four
Tumbling-E directions, letters, and so on.

1. Lines run from 20/200 down to 20/10 (:data:`snellen.geometry.SNELLEN_DENOMINATORS`).
2. Each line shows :data:`LETTERS_PER_LINE` random symbols. With enough symbols (such
   as letters), none appears twice on a line, as on a wall chart. With fewer (the E's
   four directions), the same one never appears twice in a row.
3. A line passes with :data:`PASS_MARK` right answers. As soon as too many are wrong
   for it to pass, the eye's test ends.
4. The result is the smallest line passed, as Snellen and logMAR
   (:class:`EyeResult`).

This is a screening toy, not a diagnostic tool.

Examples
--------
>>> import random
>>> test = AcuityTest(random.Random(0))
>>> test.denominator
200
>>> for _ in range(3):
...     _ = test.answer(None)  # "can't tell" three times: 20/200 can't pass
>>> test.finished, test.result().describe()
(True, 'worse than 20/200')
"""

import random
from collections.abc import Sequence
from dataclasses import dataclass

from snellen.geometry import SNELLEN_DENOMINATORS, SNELLEN_NUMERATOR, Direction, logmar

LETTERS_PER_LINE = 5
"""Optotypes shown on each line."""

PASS_MARK = 3
"""Right answers needed to pass a line (3 of 5; guessing at 1 in 4 or worse rarely gets there)."""

Symbol = Direction | str
"""What an optotype can be: a Tumbling-E :class:`~snellen.geometry.Direction` or a letter."""


@dataclass(frozen=True)
class EyeResult:
    """One eye's score.

    Parameters
    ----------
    best_denominator : int or None
        Smallest line passed (25 for 20/25); ``None`` if not even 20/200 was passed.
    logmar : float or None
        The same score as logMAR; ``None`` with ``best_denominator``.
    limited_by_screen : bool
        True if the test stopped because the next line was too small to draw at that
        distance, rather than because the eye failed it. The true acuity may be better.
    """

    best_denominator: int | None
    logmar: float | None
    limited_by_screen: bool

    def describe(self) -> str:
        """The result as text for the user.

        Returns
        -------
        str
            For example ``"20/25 (logMAR 0.10)"``, ``"20/15 or better (logMAR -0.12;
            screen limit)"`` or ``"worse than 20/200"``.

        Examples
        --------
        >>> EyeResult(40, 0.30103, False).describe()
        '20/40 (logMAR 0.30)'
        """
        if self.best_denominator is None or self.logmar is None:
            return f"worse than {SNELLEN_NUMERATOR}/{SNELLEN_DENOMINATORS[0]}"
        snellen = f"{SNELLEN_NUMERATOR}/{self.best_denominator}"
        if self.limited_by_screen:
            return f"{snellen} or better (logMAR {self.logmar:.2f}; screen limit)"
        return f"{snellen} (logMAR {self.logmar:.2f})"


class AcuityTest:
    """One eye's staircase: which line and letter is showing, and the score so far.

    Parameters
    ----------
    rng : random.Random
        Source of the random symbols; seed it for repeatable tests.
    lines : sequence of int, optional
        Snellen denominators to test, largest letters first. Default
        :data:`snellen.geometry.SNELLEN_DENOMINATORS`.
    symbols : sequence of Symbol, optional
        What each optotype can be; at least two. Default: the four Tumbling-E
        directions.

    Attributes
    ----------
    symbols : tuple of Symbol
        The current line's optotypes, left to right.
    position : int
        Index in :attr:`symbols` of the optotype being asked about.
    finished : bool
        True once this eye's test is over; answers are then ignored.
    limited_by_screen : bool
        True if it was ended by :meth:`stop_at_screen_limit`.
    """

    def __init__(
        self,
        rng: random.Random,
        lines: Sequence[int] = SNELLEN_DENOMINATORS,
        symbols: Sequence[Symbol] = tuple(Direction),
    ) -> None:
        """Start on the first (largest) line with new random symbols.

        See the class docstring for the parameters.

        Raises
        ------
        ValueError
            If fewer than two symbols are given.
        """
        if len(set(symbols)) < 2:
            raise ValueError(f"need at least two different symbols, got {symbols!r}")
        self._rng = rng
        self._lines = tuple(lines)
        self._choices = tuple(symbols)
        self._line = 0
        self._best: int | None = None
        self.limited_by_screen = False
        self.finished = False
        self._new_line()

    def _new_line(self) -> None:
        """Pick new random symbols for the current line and reset its answer counts."""
        self.position = 0
        self._right = self._wrong = 0
        if len(self._choices) >= LETTERS_PER_LINE:
            self.symbols = tuple(self._rng.sample(self._choices, LETTERS_PER_LINE))
            return
        line: list[Symbol] = []
        for _ in range(LETTERS_PER_LINE):
            choices = [c for c in self._choices if not line or c != line[-1]]
            line.append(self._rng.choice(choices))
        self.symbols = tuple(line)

    @property
    def denominator(self) -> int:
        """int: The line being shown (20/``denominator``)."""
        return self._lines[self._line]

    @property
    def current_symbol(self) -> Symbol:
        """Symbol: The optotype being asked about."""
        return self.symbols[self.position]

    def answer(self, symbol: Symbol | None) -> bool:
        """Record the user's answer for the current optotype.

        Parameters
        ----------
        symbol : Symbol or None
            What the user said it is (an E direction or a letter), or ``None`` for
            "can't tell", which counts as wrong.

        Returns
        -------
        bool
            Whether the answer was right; always ``False`` once the test has finished.

        Notes
        -----
        After the answer, the test may move on to the next line (if this one is complete and
        passed) or finish (if it can no longer pass, or the last line was passed).
        """
        if self.finished:
            return False
        right = symbol == self.current_symbol
        self._right += right
        self._wrong += not right
        self.position += 1
        if self._wrong > LETTERS_PER_LINE - PASS_MARK:
            self.finished = True
        elif self.position == LETTERS_PER_LINE:
            self._best = self.denominator
            if self._line + 1 == len(self._lines):
                self.finished = True
            else:
                self._line += 1
                self._new_line()
        return right

    def stop_at_screen_limit(self) -> None:
        """End the test because the current line is too small to draw.

        The result keeps the last line passed and sets ``limited_by_screen``. Does nothing if
        the test has already finished.
        """
        if not self.finished:
            self.finished = True
            self.limited_by_screen = True

    def result(self) -> EyeResult:
        """The score so far, which is final once :attr:`finished` is true.

        Returns
        -------
        EyeResult
        """
        return EyeResult(
            best_denominator=self._best,
            logmar=None if self._best is None else logmar(self._best),
            limited_by_screen=self.limited_by_screen,
        )
