"""The app's screens as plain state machines, with no pygame, camera or I/O.

Each module holds one screen's logic as a ``...Step`` class. A front end feeds it
tracker readings and key presses (by name: ``"space"``, ``"up"``, ``"c"``, ``"1"``)
and draws whatever it says. The desktop app does this with pygame, in the
``*_screen`` modules. Because nothing here needs pygame, MediaPipe or OpenCV, the same
logic can drive a browser version through Pyodide.

calibration
    Camera calibration with a bank card on the forehead.
screen_size
    Confirming or measuring the screen's pixel density.
chart
    The eye test itself.
"""

DISCLAIMER = "Screening toy only - not a medical test."
"""Shown on every instruction screen."""
