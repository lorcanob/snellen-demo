"""Bank-card detection for the Snellen screening toy's camera calibration.

Finds a bank card held on the forehead in a camera frame and measures its long edge in
pixels, which calibration uses as a ruler. It needs OpenCV and numpy, but not MediaPipe
or pygame, so it also runs in a browser through Pyodide.

Card detection
--------------
The card is found from straight lines rather than contours, so it still works with
fingers over parts of its edges, printing on its face and some tilt:

1. Edge pixels (Canny) are split into mostly-horizontal and mostly-vertical ones, and
   the strongest distinct Hough lines are kept for each direction.
2. Pairs of lines a plausible card height or width apart are combined into
   quadrilaterals, which are checked for card shape (and, when the eyes are known,
   for card size and position on the forehead).
3. Candidates are scored by how much of each side lies on an edge, how well the sides
   reach the corners, and whether edges stop at the corners (a card's edge does; a
   hairline or a printed band runs on).
4. The best candidates are refined to sub-pixel accuracy by fitting each side through
   gradient peaks, and the first that still passes every check is returned.

See Tropin et al., "Advanced Hough-based method for on-device document localization".

This is a screening toy, not a diagnostic tool.
"""

import cv2
import numpy as np

from snellen.geometry import (
    Line,
    Point,
    Quad,
    are_similar_lines,
    card_gap_limits_px,
    card_width_from_quad_px,
    forehead_search_box_px,
    is_plausible_card_quad,
    line_from_polar_px,
    line_gap_px,
    line_through_px,
    midpoint_px,
    normal_profile_points_px,
    parabolic_peak_offset,
    pixel_distance_px,
    quad_from_lines,
    segment_extensions_px,
    side_sample_points_px,
)
from snellen.measurements import CardDetection

# Card detection: straight lines -> candidate quadrilaterals -> scored by edge support.
# See Tropin et al., "Advanced Hough-based method for on-device document localization".
HOUGH_MIN_VOTES = 12
"""Edge pixels a line needs; low, so a card side mostly hidden by a finger still counts."""

LINES_PER_DIRECTION = 8
"""Strongest distinct lines kept for each of horizontal and vertical (8 -> 28 x 28 quads)."""

HORIZONTAL_SPREAD_DEG = 25.0
VERTICAL_SPREAD_DEG = 35.0
"""Line angles accepted around horizontal / vertical (vertical wider: perspective)."""

SUPPORT_SAMPLES = 40
SUPPORT_REACH_PX = 2
"""Points checked along each side, and how far off the side an edge pixel may be."""

MIN_SIDE_SUPPORT = 0.25
MIN_MEAN_SUPPORT = 0.5
"""Share of each side, and of all four on average, that must lie on an edge."""

END_SHARE = 0.25
"""Part of each side, at each end, checked for edge support near the corners."""

EXTENSION_PX = 10.0
OVERRUN_GAP_PX = 4.0
"""Past each corner, skip OVERRUN_GAP_PX then look EXTENSION_PX further for an edge that
carries on (so isn't the card's)."""

OVERRUN_SAMPLES = 8
OVERRUN_SKIP = 3
"""Samples spread over gap + extension (2 px apart); the 3 nearest the corner are the gap."""

MAX_OVERRUN = 0.75
"""Reject a refined candidate if an edge continues this solidly past one of its corners:
e.g. a thumb's edge inside the card, whose top/bottom sides run on to the real corners."""

MAX_REFINED_CANDIDATES = 8
"""Best distinct candidates refined and checked in turn before giving up on the frame."""

DUPLICATE_QUAD_PX = 4.0
"""Candidates whose corners all lie within this of one already checked are skipped."""

SCORE_MARGIN = 0.05
"""Candidates within this of the best score compete on size (whole card beats a strip)."""

REFINE_SAMPLES = 40
REFINE_REACH_PX = 4
"""Gradient profiles per side, and their half-length, for sub-pixel line refinement."""

PEAK_FLOOR = 0.25
"""Gradient peaks weaker than this share of the profile's strongest are noise."""


def card_width_px(frame_bgr: np.ndarray) -> float | None:
    """Long edge of the best card candidate anywhere in the frame.

    A convenience wrapper around :func:`find_card` without eye guidance.

    Parameters
    ----------
    frame_bgr : numpy.ndarray
        Camera frame, ``(height, width, 3)`` ``uint8`` in BGR order.

    Returns
    -------
    float or None
        Width in pixels, or ``None`` if no card was found.
    """
    card = find_card(frame_bgr)
    return card.width_px if card else None


def find_card(
    frame_bgr: np.ndarray, pupils_px: tuple[Point, Point] | None = None
) -> CardDetection | None:
    """Find the bank card in a frame.

    Parameters
    ----------
    frame_bgr : numpy.ndarray
        Camera frame, ``(height, width, 3)`` ``uint8`` in BGR order.
    pupils_px : tuple of Point, optional
        The two pupil centres. If given, only the forehead above them is searched
        (:func:`snellen.geometry.forehead_search_box_px`), and the card must be sized
        and placed like one held there. This is both faster and far less prone to
        picking up picture frames or windows behind the user.

    Returns
    -------
    CardDetection or None
        The card, or ``None`` if nothing passed every check.

    Notes
    -----
    See the module docstring for the steps. If a side is too hidden to be measured
    reliably, it returns ``None`` rather than a wrong width. Calibration collects many
    frames, so a few misses don't matter.
    """
    frame_h, frame_w = frame_bgr.shape[:2]
    x0, y0, x1, y1 = 0, 0, frame_w, frame_h
    ipd = eye_mid = None
    if pupils_px is not None:
        box = forehead_search_box_px(pupils_px[0], pupils_px[1], frame_w, frame_h)
        x0, y0, x1, y1 = (int(box[0]), int(box[1]), int(np.ceil(box[2])), int(np.ceil(box[3])))
        ipd, eye_mid = pixel_distance_px(*pupils_px), midpoint_px(*pupils_px)
    if x1 - x0 < 16 or y1 - y0 < 16:
        return None
    origin = (float(x0), float(y0))

    gray = cv2.GaussianBlur(cv2.cvtColor(frame_bgr[y0:y1, x0:x1], cv2.COLOR_BGR2GRAY), (5, 5), 0)
    gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
    edges = cv2.Canny(gray, 30, 90) > 0  # TODO: Calibrate against real world cases
    # Split edge pixels by direction: horizontal card sides vs vertical ones.
    across = np.abs(gy) > np.abs(gx)
    horizontal = np.where(edges & across, 255, 0).astype(np.uint8)
    vertical = np.where(edges & ~across, 255, 0).astype(np.uint8)

    centre = midpoint_px(origin, (float(x1), float(y1)))
    h_lines = _strongest_lines(
        horizontal, [(90 - HORIZONTAL_SPREAD_DEG, 90 + HORIZONTAL_SPREAD_DEG)], origin, centre
    )
    v_lines = _strongest_lines(
        vertical, [(0, VERTICAL_SPREAD_DEG), (180 - VERTICAL_SPREAD_DEG, 180)], origin, centre
    )
    (w_lo, w_hi), (h_lo, h_hi) = card_gap_limits_px(frame_w, ipd)
    h_pairs = [
        (a, b)
        for i, a in enumerate(h_lines)
        for b in h_lines[i + 1 :]
        if h_lo <= line_gap_px(a, b, centre) <= h_hi
    ]
    v_pairs = [
        (a, b)
        for i, a in enumerate(v_lines)
        for b in v_lines[i + 1 :]
        if w_lo <= line_gap_px(a, b, centre) <= w_hi
    ]
    near = np.ones((2 * SUPPORT_REACH_PX + 1,) * 2, np.uint8)
    support_maps = (cv2.dilate(horizontal, near), cv2.dilate(vertical, near))

    candidates = []  # (score, area, (top, right, bottom, left))
    for top, bottom in h_pairs:
        for left, right in v_pairs:
            quad = quad_from_lines(top, bottom, left, right)
            if quad is None or not is_plausible_card_quad(quad, frame_w, ipd, eye_mid):
                continue
            support = _side_support(quad, support_maps, origin)  # cheap check first
            if min(support) < MIN_SIDE_SUPPORT or np.mean(support) < MIN_MEAN_SUPPORT:
                continue
            score = float(np.mean(_side_scores(quad, support, support_maps, origin)))
            area = cv2.contourArea(np.array(quad, np.float32))
            candidates.append((score, area, (top, right, bottom, left)))
    if not candidates:
        return None

    # Best first: within SCORE_MARGIN of the top score, larger beats smaller (a whole
    # card beats a printed strip of it); then the rest by score.
    best_score = max(c[0] for c in candidates)

    def rank(c: tuple) -> tuple[bool, float]:
        """Sort key: (near the best score, then area if near it, else score)."""
        near_best = c[0] >= best_score - SCORE_MARGIN
        return near_best, c[1] if near_best else c[0]

    ranked = sorted(candidates, key=rank)
    thin_maps = (cv2.dilate(horizontal, None), cv2.dilate(vertical, None))  # +-1 px
    tried: list[Quad] = []
    for _, _, (top, right, bottom, left) in reversed(ranked):
        if len(tried) == MAX_REFINED_CANDIDATES:
            break
        rough = quad_from_lines(top, bottom, left, right)
        if any(
            max(pixel_distance_px(c, d) for c, d in zip(rough, other, strict=True))
            <= DUPLICATE_QUAD_PX
            for other in tried
        ):
            continue  # Hough's near-duplicate of a quad already checked
        tried.append(rough)
        quad = _refined_quad(top, right, bottom, left, gx, gy, origin)
        if quad is None or not is_plausible_card_quad(quad, frame_w, ipd, eye_mid):
            continue
        # A card's edges stop at its corners. With exact (refined) lines, an edge that
        # carries on past a corner means these aren't the card's corners: e.g. a thumb's
        # edge inside the card, whose top and bottom run on to the real corners.
        if max(_overruns(quad, thin_maps, origin)) >= MAX_OVERRUN:
            continue
        corners = tuple((float(x), float(y)) for x, y in quad)
        return CardDetection(width_px=float(card_width_from_quad_px(quad)), corners_px=corners)
    return None


def _refined_quad(
    top: Line, right: Line, bottom: Line, left: Line, gx: np.ndarray, gy: np.ndarray, origin: Point
) -> Quad | None:
    """The candidate quad after moving each side onto its sub-pixel gradient peak.

    Parameters
    ----------
    top, right, bottom, left : Line
        The candidate's rough Hough lines.
    gx, gy : numpy.ndarray
        Horizontal and vertical Sobel gradients of the search region.
    origin : Point
        The search region's top-left corner in frame coordinates.

    Returns
    -------
    Quad or None
        Refined corners, or ``None`` if refined lines no longer meet.
    """
    rough = quad_from_lines(top, bottom, left, right)
    if rough is None:
        return None
    return quad_from_lines(
        _refine_line(top, rough[0], rough[1], gy, origin),
        _refine_line(bottom, rough[3], rough[2], gy, origin),
        _refine_line(left, rough[0], rough[3], gx, origin),
        _refine_line(right, rough[1], rough[2], gx, origin),
    )


def _overruns(quad: Quad, edge_maps: tuple[np.ndarray, np.ndarray], origin: Point) -> list[float]:
    """How solidly edges carry on past each corner.

    Parameters
    ----------
    quad : Quad
        Candidate corners.
    edge_maps : tuple of numpy.ndarray
        ``(horizontal, vertical)`` edge maps, slightly dilated.
    origin : Point
        The maps' top-left corner in frame coordinates.

    Returns
    -------
    list of float
        For each of the 8 side ends, the share of the line just past the corner that lies
        on an edge (0 = the edge stops at the corner, as a card's does).
    """
    shares = []
    for a, b, edge_map in _sides(quad, *edge_maps):
        for points in _overrun_points(a, b):
            shares.append(_edge_share(points, edge_map, origin))
    return shares


def _sides(
    quad: Quad, horizontal: np.ndarray, vertical: np.ndarray
) -> list[tuple[Point, Point, np.ndarray]]:
    """The four sides of a quad, each with the edge map matching its direction.

    Returns
    -------
    list of tuple
        ``(start, end, edge_map)`` for top, right, bottom and left. The bottom runs
        left to right and the left top to bottom, like the top and right sides.
    """
    return [
        (quad[0], quad[1], horizontal),
        (quad[1], quad[2], vertical),
        (quad[3], quad[2], horizontal),
        (quad[0], quad[3], vertical),
    ]


def _strongest_lines(
    edge_map: np.ndarray,
    angle_ranges_deg: list[tuple[float, float]],
    origin: Point,
    centre: Point,
) -> list[Line]:
    """The strongest distinct straight lines in an edge map, within given angle ranges.

    Parameters
    ----------
    edge_map : numpy.ndarray
        ``uint8`` edge image (255 = edge) of the search region.
    angle_ranges_deg : list of tuple of float
        ``(low, high)`` ranges for the Hough normal angle, in degrees.
    origin : Point
        The region's top-left corner in frame coordinates.
    centre : Point
        Where near-duplicate lines are compared (the region's centre).

    Returns
    -------
    list of Line
        Up to :data:`LINES_PER_DIRECTION` lines in frame coordinates, sorted by ``rho``
        (top to bottom, or left to right).
    """
    found = []
    for low, high in angle_ranges_deg:
        lines = cv2.HoughLinesWithAccumulator(
            edge_map,
            1,
            np.pi / 180,
            HOUGH_MIN_VOTES,
            min_theta=np.radians(low),
            max_theta=np.radians(high),
        )
        if lines is not None:
            # (N, 3) in OpenCV 5, (N, 1, 3) before.
            found.extend((votes, rho, theta) for rho, theta, votes in lines.reshape(-1, 3))
    kept: list[Line] = []
    for _, rho, theta in sorted(found, reverse=True):
        line = line_from_polar_px(float(rho), float(theta), origin)
        if not any(
            are_similar_lines(line, k, max_angle_deg=1.5, max_offset_px=2, at_px=centre)
            for k in kept
        ):
            kept.append(line)
        if len(kept) == LINES_PER_DIRECTION:
            break
    return sorted(kept, key=lambda line: line[2])  # top-to-bottom / left-to-right


def _side_support(
    quad: Quad, support_maps: tuple[np.ndarray, np.ndarray], origin: Point
) -> list[float]:
    """How much of each side of a quad lies on a matching edge.

    Returns
    -------
    list of float
        For top, right, bottom and left: the share (0 to 1) of
        :data:`SUPPORT_SAMPLES` points along the side that land on an edge pixel.
    """
    return [
        _edge_share(side_sample_points_px(a, b, SUPPORT_SAMPLES), edge_map, origin)
        for a, b, edge_map in _sides(quad, *support_maps)
    ]


def _side_scores(
    quad: Quad,
    support: list[float],
    support_maps: tuple[np.ndarray, np.ndarray],
    origin: Point,
) -> list[float]:
    """Score each side of a candidate card.

    A side scores its support (share on an edge), plus support near both corners, minus
    edge carrying on past them. A card edge stops at its corners, while a hairline runs on,
    and a fingertip's edge (inside the card) never reaches them.

    Parameters
    ----------
    quad : Quad
        Candidate corners.
    support : list of float
        The sides' support, from :func:`_side_support`.
    support_maps : tuple of numpy.ndarray
        ``(horizontal, vertical)`` dilated edge maps.
    origin : Point
        The maps' top-left corner in frame coordinates.

    Returns
    -------
    list of float
        Scores for top, right, bottom and left; roughly -1 to 2, higher is better.
    """
    n, k = SUPPORT_SAMPLES, int(SUPPORT_SAMPLES * END_SHARE)
    scores = []
    for body, (a, b, edge_map) in zip(support, _sides(quad, *support_maps), strict=True):
        along = side_sample_points_px(a, b, n, inset=0.02)
        past_a, past_b = _overrun_points(a, b)
        hits = _on_edge(along[:k] + along[-k:] + past_a + past_b, edge_map, origin)
        ends, beyond = hits[: 2 * k].mean(), hits[2 * k :].mean()
        scores.append(float(body + ends - beyond))
    return scores


def _overrun_points(a: Point, b: Point) -> tuple[list[Point], list[Point]]:
    """Sample points on a side's line just past each of its corners.

    The first :data:`OVERRUN_GAP_PX` past each corner is skipped, since corners are
    rounded and blurred.

    Returns
    -------
    tuple of list of Point
        ``(past_a, past_b)`` points beyond ``a`` and beyond ``b``.
    """
    (a_out, a_in), (b_in, b_out) = segment_extensions_px(a, b, OVERRUN_GAP_PX + EXTENSION_PX)
    far = OVERRUN_SAMPLES - OVERRUN_SKIP
    return (
        side_sample_points_px(a_out, a_in, OVERRUN_SAMPLES, inset=0.0)[:far],
        side_sample_points_px(b_in, b_out, OVERRUN_SAMPLES, inset=0.0)[OVERRUN_SKIP:],
    )


def _on_edge(points: list[Point], edge_map: np.ndarray, origin: Point) -> np.ndarray:
    """For each point, whether it lands on an edge pixel.

    Parameters
    ----------
    points : list of Point
        Points in frame coordinates.
    edge_map : numpy.ndarray
        Edge image of the search region.
    origin : Point
        The region's top-left corner in frame coordinates.

    Returns
    -------
    numpy.ndarray
        Boolean array, one entry per point; points outside the map are ``False``.
    """
    xy = np.round(np.array(points) - origin).astype(int)
    xs, ys = xy[:, 0], xy[:, 1]
    inside = (xs >= 0) & (ys >= 0) & (xs < edge_map.shape[1]) & (ys < edge_map.shape[0])
    hits = np.zeros(len(points), bool)
    hits[inside] = edge_map[ys[inside], xs[inside]] > 0
    return hits


def _edge_share(points: list[Point], edge_map: np.ndarray, origin: Point) -> float:
    """Share (0 to 1) of the points that land on an edge pixel; see :func:`_on_edge`."""
    return float(_on_edge(points, edge_map, origin).mean())


def _nearest_peak(values: np.ndarray) -> int | None:
    """Index of the local maximum closest to the middle of a gradient profile.

    Nearest, not strongest: a stronger edge a few pixels away (a hairline just above the
    card) must not pull the card's side onto it.

    Parameters
    ----------
    values : numpy.ndarray
        Gradient magnitudes sampled across an edge.

    Returns
    -------
    int or None
        Index of the peak, or ``None`` if there is no peak above :data:`PEAK_FLOOR` of
        the strongest value.
    """
    middle = len(values) // 2
    floor = PEAK_FLOOR * float(values.max())
    peaks = [
        k
        for k in range(1, len(values) - 1)
        if values[k] > floor and values[k] >= values[k - 1] and values[k] >= values[k + 1]
    ]
    return min(peaks, key=lambda k: abs(k - middle)) if peaks else None


def _refine_line(line: Line, a: Point, b: Point, gradient: np.ndarray, origin: Point) -> Line:
    """Fit a side's line through sub-pixel gradient peaks found across it.

    Parameters
    ----------
    line : Line
        The rough line.
    a, b : Point
        The side's rough end points.
    gradient : numpy.ndarray
        Sobel gradient across the side (``gy`` for horizontal sides, ``gx`` for vertical).
    origin : Point
        The gradient image's top-left corner in frame coordinates.

    Returns
    -------
    Line
        The refined line, or the rough one if too few clear peaks were found. Weak peaks
        are dropped first, since they're where a finger hides the edge.
    """
    magnitude = np.abs(gradient)
    peaks = []
    for point in side_sample_points_px(a, b, REFINE_SAMPLES):
        profile_points = normal_profile_points_px(point, line, REFINE_REACH_PX)
        coords = np.array(profile_points, np.float32) - np.array(origin, np.float32)
        values = cv2.remap(
            magnitude,
            coords[:, 0].reshape(1, -1),
            coords[:, 1].reshape(1, -1),
            cv2.INTER_LINEAR,
            borderMode=cv2.BORDER_CONSTANT,
            borderValue=0,
        )[0]
        k = _nearest_peak(values)
        if k is not None:
            peaks.append((values[k], k, values, profile_points))
    if len(peaks) < 6:
        return line
    # Drop weak peaks: those are where a finger or gap hides the card's edge.
    strongest = np.median([p[0] for p in peaks])
    fit_points = []
    for value, k, values, profile_points in peaks:
        if value < 0.5 * strongest:
            continue
        delta = parabolic_peak_offset(values[k - 1], values[k], values[k + 1])
        (ax, ay), (bx, by) = profile_points[k], profile_points[k + 1]
        fit_points.append((ax + delta * (bx - ax), ay + delta * (by - ay)))
    if len(fit_points) < 6:
        return line
    vx, vy, px, py = cv2.fitLine(np.array(fit_points, np.float32), cv2.DIST_HUBER, 0, 0.01, 0.01)
    return line_through_px((float(px[0]), float(py[0])), (float(vx[0]), float(vy[0])), like=line)
