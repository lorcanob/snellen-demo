"""Plain-number results: what the tracker reports for each camera frame, and the
screen's measured pixel density.

These dataclasses are shared by the tracker and screen-size code (which fill them in),
the screens and steps (which read them) and the debug view. They depend on nothing but :mod:`snellen.geometry`,
so they load anywhere, including in a browser through Pyodide.
"""

from dataclasses import dataclass
from typing import Protocol

from snellen.geometry import Point, Quad, pixel_distance_px


@dataclass(frozen=True)
class Reading:
    """One frame's measurements, as plain pixel numbers.

    Any field is ``None`` when its feature wasn't detected in the frame.

    Parameters
    ----------
    card_width_px : float or None
        Long edge of the bank card on the forehead.
    ipd_px : float or None
        Distance between the two pupil centres.
    left_nose_px, right_nose_px : float or None, optional
        Distance from each of the subject's pupils to the bridge of the nose.
    left_iris_px, right_iris_px : float or None, optional
        Diameter of each of the subject's irises.

    Notes
    -----
    "Left" and "right" mean the subject's own eyes. The one-eye spans let distance be
    measured while the other eye is covered (see
    :func:`snellen.geometry.one_eye_distance_mm`).
    """

    card_width_px: float | None
    ipd_px: float | None
    left_nose_px: float | None = None
    right_nose_px: float | None = None
    left_iris_px: float | None = None
    right_iris_px: float | None = None


@dataclass(frozen=True)
class EyeSpans:
    """Face spans that need only one eye visible, for each of the subject's eyes.

    Parameters
    ----------
    left_nose_px, right_nose_px : float
        Pupil to nose bridge, in pixels.
    left_iris_px, right_iris_px : float
        Iris diameter (mean of horizontal and vertical), in pixels.
    """

    left_nose_px: float
    right_nose_px: float
    left_iris_px: float
    right_iris_px: float


@dataclass(frozen=True)
class CardDetection:
    """A bank card found in a frame.

    Parameters
    ----------
    width_px : float
        Long-edge length in pixels; for a tilted card, the mean of the two long sides.
    corners_px : Quad
        Corners clockwise from top-left, from edge lines refined to sub-pixel accuracy.
    """

    width_px: float
    corners_px: Quad


@dataclass(frozen=True)
class Detection:
    """Everything found in one frame, with positions (for drawing) as well as sizes.

    Parameters
    ----------
    card : CardDetection or None
        The card, if found.
    pupils_px : tuple of Point or None
        The two iris centres in face-mesh order: the subject's right eye first, which is
        on the image's left for an unmirrored camera.
    spans : EyeSpans or None, optional
        One-eye spans, if the face was found.
    """

    card: CardDetection | None
    pupils_px: tuple[Point, Point] | None
    spans: EyeSpans | None = None

    def reading(self) -> Reading:
        """The plain numbers callers need, without positions.

        Returns
        -------
        Reading
            Card width, pupil distance and one-eye spans in pixels; ``None`` where missing.
        """
        spans = self.spans
        return Reading(
            card_width_px=self.card.width_px if self.card else None,
            ipd_px=pixel_distance_px(*self.pupils_px) if self.pupils_px else None,
            left_nose_px=spans.left_nose_px if spans else None,
            right_nose_px=spans.right_nose_px if spans else None,
            left_iris_px=spans.left_iris_px if spans else None,
            right_iris_px=spans.right_iris_px if spans else None,
        )


class ReadingSource(Protocol):
    """Anything that can produce tracker readings, such as :class:`snellen.tracker.Tracker`."""

    def read(self) -> Reading | None:
        """The next reading, or ``None`` if the camera gave no picture."""
        ...


@dataclass(frozen=True)
class ScreenRecord:
    """A screen density and where it came from.

    Parameters
    ----------
    px_per_mm : float
        Window pixels per mm.
    source : str
        ``"hardware"`` (reported by the operating system) or ``"card"`` (measured by
        the user).
    """

    px_per_mm: float
    source: str
