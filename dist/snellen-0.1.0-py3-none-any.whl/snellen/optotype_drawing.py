"""Drawing optotypes with pygame, at exact (fractional) heights.

Each kind of optotype in :mod:`snellen.optotypes` has a renderer here.
:func:`renderer_for` picks the right one. Every renderer draws one optotype as a
transparent, anti-aliased surface whose middle is the optotype's middle.

* The Tumbling E and the Landolt C are drawn in code from their geometry
  (:func:`snellen.geometry.tumbling_e_cells`, :func:`snellen.geometry.landolt_c_gap`).
* Letters are drawn in the bundled *Optician Sans* font.

Small optotypes are drawn up to :data:`SUPERSAMPLE` times larger and then shrunk. Edges
that fall between pixels come out partly inked, so a 7.5 px E really looks 7.5 px tall.

Letter sizing
-------------
A chart letter's height is its cap height: the height of flat-topped, flat-bottomed
letters such as E. Round letters (C, O) come out about 4% taller, as type designers and
printed charts do, so they look the same size. Optician Sans' strokes are 1/5 of the
cap height and its letters are about as wide as they are tall, matching Snellen's
5 x 5 design.

Font licence
------------
Optician Sans is by ANTI Hamar and Fábio Duarte Martins
(https://github.com/anewtypeofinterference/Optician-Sans), released under the SIL
Open Font License 1.1. The licence is in ``fonts/OFL.txt`` next to the font, and must
stay with it.
"""

import math
from importlib.resources import files
from pathlib import Path
from typing import Protocol

import pygame

from snellen.acuity import Symbol
from snellen.geometry import LANDOLT_C_RADII, Direction, landolt_c_gap, tumbling_e_cells
from snellen.optotypes import LandoltC, Optotype, SnellenLetters, TumblingE

SUPERSAMPLE = 8
"""Small optotypes are drawn up to this many times larger, then shrunk, so edges that fall
between pixels come out partly inked and fractional sizes look right."""

SUPERSAMPLE_UP_TO_PX = 256
"""Supersampling is reduced so the large drawing stays at most about this tall; big
letters don't need sub-pixel accuracy, and huge canvases are slow."""

FONT_PATH = Path(str(files("snellen").joinpath("fonts", "OpticianSans.ttf")))
"""The bundled Optician Sans font (SIL Open Font License; see fonts/OFL.txt)."""

GLYPH_FONT_PX = 800
"""Font size letters are first rendered at (cap height about 400 px), before scaling."""

OVERSHOOT_MARGIN = 0.1
"""Room kept above and below the cap height for round letters' overshoot, as a share of
the cap height."""

Colour = tuple[int, int, int]


class Renderer(Protocol):
    """Draws one kind of optotype."""

    def render(self, symbol: Symbol, height_px: float, colour: Colour) -> pygame.Surface:
        """Draw one optotype.

        Parameters
        ----------
        symbol : Symbol
            Which one, from the optotype's ``symbols``.
        height_px : float
            Optotype height in screen pixels (fractional heights are honoured).
        colour : tuple of int
            RGB ink colour.

        Returns
        -------
        pygame.Surface
            A transparent surface with the optotype centred on it, so it can be placed
            with ``get_rect(center=...)``.
        """
        ...


def _supersample(height_px: float) -> int:
    """How many times larger to draw an optotype of this height before shrinking it.

    Examples
    --------
    >>> _supersample(7.3), _supersample(64.0), _supersample(400.0)
    (8, 4, 1)
    """
    return max(1, min(SUPERSAMPLE, int(SUPERSAMPLE_UP_TO_PX // height_px)))


def _direction(symbol: Symbol, kind: str) -> Direction:
    """``symbol`` as a Direction, or a TypeError naming the optotype ``kind``."""
    if not isinstance(symbol, Direction):
        raise TypeError(f"a {kind} needs a Direction, got {symbol!r}")
    return symbol


class TumblingERenderer:
    """Draws :class:`~snellen.optotypes.TumblingE`: crisp rectangles, supersampled."""

    def render(self, symbol: Symbol, height_px: float, colour: Colour) -> pygame.Surface:
        """Draw an anti-aliased E; see :meth:`Renderer.render`.

        Returns
        -------
        pygame.Surface
            A transparent square ``ceil(height_px) + 2`` pixels wide, E centred.

        Raises
        ------
        TypeError
            If ``symbol`` is not a :class:`~snellen.geometry.Direction`.
        """
        direction = _direction(symbol, "Tumbling E")
        scale = _supersample(height_px)
        side = math.ceil(height_px) + 2
        big = pygame.Surface((side * scale, side * scale), pygame.SRCALPHA)
        cell = height_px * scale / 5
        offset = (side * scale - 5 * cell) / 2
        for x, y, w, h in tumbling_e_cells(direction):
            left, top = round(offset + x * cell), round(offset + y * cell)
            right, bottom = round(offset + (x + w) * cell), round(offset + (y + h) * cell)
            pygame.draw.rect(big, colour, pygame.Rect(left, top, right - left, bottom - top))
        return pygame.transform.smoothscale(big, (side, side))


class LandoltCRenderer:
    """Draws :class:`~snellen.optotypes.LandoltC`: a disc, minus the hole and the gap."""

    def render(self, symbol: Symbol, height_px: float, colour: Colour) -> pygame.Surface:
        """Draw an anti-aliased Landolt C; see :meth:`Renderer.render`.

        Returns
        -------
        pygame.Surface
            A transparent square ``ceil(height_px) + 2`` pixels wide, ring centred.

        Raises
        ------
        TypeError
            If ``symbol`` is not a :class:`~snellen.geometry.Direction`.
        """
        direction = _direction(symbol, "Landolt C")
        scale = _supersample(height_px)
        side = math.ceil(height_px) + 2
        big = pygame.Surface((side * scale, side * scale), pygame.SRCALPHA)
        cell = height_px * scale / 5
        centre = (side * scale / 2, side * scale / 2)
        outer, inner = LANDOLT_C_RADII
        clear = (0, 0, 0, 0)  # pygame.draw writes this as-is: it erases, not blends
        pygame.draw.circle(big, colour, centre, outer * cell)
        pygame.draw.circle(big, clear, centre, inner * cell)
        x, y, w, h = landolt_c_gap(direction)
        offset = centre[0] - 2.5 * cell
        left, top = round(offset + x * cell), round(offset + y * cell)
        right, bottom = round(offset + (x + w) * cell), round(offset + (y + h) * cell)
        pygame.draw.rect(big, clear, pygame.Rect(left, top, right - left, bottom - top))
        return pygame.transform.smoothscale(big, (side, side))


class LetterRenderer:
    """Draws letters in a TrueType font (the bundled Optician Sans by default).

    Parameters
    ----------
    letters : sequence of str
        The letters this chart uses; anything else is refused.
    font_path : pathlib.Path, optional
        The font; :data:`FONT_PATH` by default.

    Notes
    -----
    Each letter is rendered once, large, and cached; drawing a letter then only scales
    that image. Create the renderer after ``pygame.init()`` and don't keep it across
    ``pygame.quit()``.
    """

    def __init__(self, letters: tuple[Symbol, ...], font_path: Path = FONT_PATH) -> None:
        """Remember the letters and font; nothing is loaded until the first draw."""
        self.letters = tuple(letters)
        self.font_path = font_path
        self._font: pygame.font.Font | None = None
        self._cap: tuple[int, int] | None = None
        self._glyphs: dict[tuple[str, Colour], pygame.Surface] = {}

    def _ink_rows(self, letter: str) -> tuple[int, int]:
        """(first, last + 1) rows with ink when ``letter`` is rendered at full size."""
        assert self._font is not None
        alpha = pygame.surfarray.pixels_alpha(self._font.render(letter, True, (0, 0, 0)))
        rows = [y for y in range(alpha.shape[1]) if alpha[:, y].max() > 127]
        return rows[0], rows[-1] + 1

    def _glyph(self, letter: str, colour: Colour) -> pygame.Surface:
        """The letter at full size, cropped to its ink sideways and to the cap height
        (plus :data:`OVERSHOOT_MARGIN` above and below) vertically; cached."""
        if self._font is None:
            self._font = pygame.font.Font(str(self.font_path), GLYPH_FONT_PX)
            self._cap = self._ink_rows("E")  # flat top and bottom: the cap height
        assert self._cap is not None
        key = (letter, colour)
        if key not in self._glyphs:
            rendered = self._font.render(letter, True, colour)
            ink = rendered.get_bounding_rect(min_alpha=1)
            top, bottom = self._cap
            margin = round(OVERSHOOT_MARGIN * (bottom - top))
            crop = pygame.Rect(ink.x, top - margin, ink.width, bottom - top + 2 * margin)
            self._glyphs[key] = rendered.subsurface(crop.clip(rendered.get_rect())).copy()
        return self._glyphs[key]

    def render(self, symbol: Symbol, height_px: float, colour: Colour) -> pygame.Surface:
        """Draw an anti-aliased letter whose cap height is ``height_px``; see
        :meth:`Renderer.render`.

        Raises
        ------
        ValueError
            If ``symbol`` isn't one of this chart's letters.
        """
        if symbol not in self.letters or not isinstance(symbol, str):
            raise ValueError(f"not one of this chart's letters: {symbol!r}")
        glyph = self._glyph(symbol, colour)
        assert self._cap is not None
        k = height_px / (self._cap[1] - self._cap[0])
        w, h = glyph.get_width() * k, glyph.get_height() * k
        out_w, out_h = math.ceil(w) + 2, math.ceil(h) + 2
        scale = _supersample(height_px)
        big = pygame.Surface((out_w * scale, out_h * scale), pygame.SRCALPHA)
        scaled = pygame.transform.smoothscale(
            glyph, (max(1, round(w * scale)), max(1, round(h * scale)))
        )
        big.blit(scaled, scaled.get_rect(center=(out_w * scale / 2, out_h * scale / 2)))
        return pygame.transform.smoothscale(big, (out_w, out_h))


def renderer_for(optotype: Optotype) -> Renderer:
    """The pygame renderer for a kind of optotype.

    Parameters
    ----------
    optotype : Optotype
        One of the kinds in :mod:`snellen.optotypes`.

    Returns
    -------
    Renderer

    Raises
    ------
    TypeError
        If there is no renderer for that kind.
    """
    if isinstance(optotype, TumblingE):
        return TumblingERenderer()
    if isinstance(optotype, LandoltC):
        return LandoltCRenderer()
    if isinstance(optotype, SnellenLetters):
        return LetterRenderer(optotype.symbols)
    raise TypeError(f"no renderer for {type(optotype).__name__}")
