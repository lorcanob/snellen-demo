"""Eye test step: the logic behind :mod:`snellen.chart_screen`, with no pygame.

The user first chooses a chart: Snellen letters (typed on the keyboard), Tumbling E or
Landolt C (both answered with the arrow keys); see :mod:`snellen.optotypes`. The chart is sized live
to the user's distance and tests one eye at a time: the left eye first (right eye
covered), then the right. Each line has five random optotypes. The user answers each,
or presses SPACE if they can't tell, and the staircase scoring in
:mod:`snellen.acuity` decides when to move to a smaller line and when to stop.

How the distance is measured
----------------------------
* **Both eyes open** (instructions, before covering): from the pupil distance, with
  :func:`snellen.geometry.viewing_distance_mm`.
* **One eye covered** (during the test): from the open eye's own spans (pupil to nose
  bridge, iris), with :func:`snellen.geometry.one_eye_distance_mm`. Before the user
  covers an eye, the one-eye distance is compared with the both-eyes distance over
  :data:`AGREEMENT_FRAMES` frames. It is only trusted if the two agree within
  :data:`MAX_DISAGREEMENT`; otherwise the letter size is held for that eye.
* Every distance is smoothed over :data:`DISTANCE_WINDOW` frames with
  :func:`snellen.geometry.steady_distance_mm`. When the samples jump about, or the
  face is lost, the letters keep their last size and a warning is shown.

Letter size comes from :func:`snellen.geometry.optotype_height_px`. A line too small to
draw faithfully (:func:`snellen.geometry.smallest_renderable_denominator`) ends that
eye's test, and the result is marked as limited by the screen.

This is a screening toy, not a diagnostic tool.
"""

import random
from collections import deque
from collections.abc import Sequence
from enum import Enum, auto
from statistics import median

from snellen.acuity import AcuityTest, EyeResult, Symbol
from snellen.geometry import (
    Calibration,
    Eye,
    one_eye_distance_mm,
    optotype_height_px,
    smallest_renderable_denominator,
    steady_distance_mm,
    viewing_distance_mm,
)
from snellen.measurements import Reading
from snellen.optotypes import Optotype, available_optotypes
from snellen.steps import DISCLAIMER

EYE_ORDER = (Eye.LEFT, Eye.RIGHT)
"""Eyes in the order they are tested."""

DISTANCE_WINDOW = 15
"""Distance samples the letter size follows (about half a second)."""

MIN_SAMPLES = 5
"""Samples needed before the size follows a new source (e.g. one eye after covering)."""

AGREEMENT_FRAMES = 15
"""Frames compared before covering an eye: one-eye vs both-eyes distance."""

MAX_DISAGREEMENT = 0.10
"""One-eye distance may differ this much from the both-eyes one and still be trusted."""

NO_FACE_FRAMES = 30
"""Frames without a usable distance before warning that the face can't be seen (~1 s)."""


class ChartPhase(Enum):
    """Where the eye test screen is.

    Attributes
    ----------
    CHOOSE
        Choosing the chart type (skipped when there is only one).
    INSTRUCT
        Explaining the test.
    COVER
        Measuring the both-eyes distance, then asking the user to cover the other eye.
    TESTING
        Showing the chart for one eye.
    RESULTS
        Showing both eyes' results.
    """

    CHOOSE = auto()
    INSTRUCT = auto()
    COVER = auto()
    TESTING = auto()
    RESULTS = auto()


def _other(eye: Eye) -> Eye:
    """The opposite eye: the one to cover while ``eye`` is tested."""
    return Eye.RIGHT if eye is Eye.LEFT else Eye.LEFT


class ChartStep:
    """State of the eye test screen, with no pygame, so it can be tested directly.

    Call :meth:`feed` with every tracker reading and :meth:`press` with every key press
    (:meth:`choose`, :meth:`advance` and :meth:`answer` can also be called directly).
    Read :meth:`lines`, :meth:`status`, :meth:`warning` and :attr:`letter_height_px` to
    draw it.

    Parameters
    ----------
    calibration : Calibration
        The user's camera calibration.
    px_per_mm : float
        Screen pixel density, in window pixels per mm.
    rng : random.Random, optional
        Source of the random optotypes; pass a seeded one for repeatable tests. A fresh,
        unseeded generator by default.
    optotypes : sequence of Optotype, optional
        The charts offered, in order; :func:`snellen.optotypes.available_optotypes` by
        default. With just one, the choice page is skipped.

    Attributes
    ----------
    phase : ChartPhase
        Current phase.
    optotypes : tuple of Optotype
        The charts offered.
    optotype : Optotype or None
        The chosen chart; ``None`` until chosen.
    test : AcuityTest or None
        The current eye's staircase, while testing.
    results : dict of Eye to EyeResult
        Results so far, filled in as each eye finishes.
    distance_mm : float or None
        The distance the letters are currently sized for; ``None`` until first measured.
    live_tracking : bool
        Whether the current eye's test follows the one-eye distance (True) or holds the
        letter size (False).
    holding : bool
        True when the latest samples were too inconsistent to follow.
    finished : bool
        True once the user has left the results; the loop then returns.
    """

    def __init__(
        self,
        calibration: Calibration,
        px_per_mm: float,
        rng: random.Random | None = None,
        optotypes: Sequence[Optotype] | None = None,
    ) -> None:
        """Start on the chart choice (or the instructions) with no distance known yet.

        See the class docstring for the parameters.

        Raises
        ------
        ValueError
            If ``optotypes`` is empty.
        """
        self.calibration = calibration
        self.px_per_mm = px_per_mm
        self._rng = rng or random.Random()
        self.optotypes = tuple(available_optotypes() if optotypes is None else optotypes)
        if not self.optotypes:
            raise ValueError("at least one optotype is needed")
        self.optotype: Optotype | None = None
        self.phase = ChartPhase.CHOOSE
        if len(self.optotypes) == 1:
            self.choose(0)
        self.finished = False
        self.results: dict[Eye, EyeResult] = {}
        self._eye_index = 0
        self.test: AcuityTest | None = None
        self.live_tracking = False
        self.distance_mm: float | None = None
        self.holding = False
        self._samples: deque[float] = deque(maxlen=DISTANCE_WINDOW)
        self._agreement: deque[float] = deque(maxlen=AGREEMENT_FRAMES)
        self._frames_without_distance = 0
        self._cover_frames = 0

    @property
    def eye(self) -> Eye:
        """Eye: The eye being tested, or about to be."""
        return EYE_ORDER[self._eye_index]

    @property
    def face_lost(self) -> bool:
        """bool: True after :data:`NO_FACE_FRAMES` frames in a row with no usable distance."""
        return self._frames_without_distance >= NO_FACE_FRAMES

    @property
    def letter_height_px(self) -> float | None:
        """float or None: Height of the Es on the current line, in screen pixels.

        ``None`` before a test is running or before any distance is known.
        """
        if self.test is None or self.distance_mm is None:
            return None
        return optotype_height_px(self.distance_mm, self.test.denominator, self.px_per_mm)

    def _one_eye_distance_mm(self, reading: Reading, eye: Eye) -> float | None:
        """Distance from one eye's spans in this reading, or ``None`` if none is usable.

        Parameters
        ----------
        reading : Reading
            The tracker reading.
        eye : Eye
            Which eye's spans to use.

        Returns
        -------
        float or None
            Distance in mm.
        """
        nose_mm, iris_mm = self.calibration.spans_mm(eye)
        if eye is Eye.LEFT:
            nose_px, iris_px = reading.left_nose_px, reading.left_iris_px
        else:
            nose_px, iris_px = reading.right_nose_px, reading.right_iris_px
        return one_eye_distance_mm(
            nose_px, iris_px, nose_mm, iris_mm, self.calibration.focal_length_px
        )

    def feed(self, reading: Reading | None) -> None:
        """Update the distance from one tracker reading.

        Parameters
        ----------
        reading : Reading or None
            The latest reading, or ``None`` if the camera gave no picture.

        Notes
        -----
        * While testing with live tracking, the open eye's spans are used. With the size
          held, readings are ignored.
        * Otherwise the pupil distance is used. In the ``COVER`` phase the ratio of one-eye
          to both-eyes distance is also recorded, until :attr:`ready_to_cover`. After that
          the distance is locked, because covering an eye spoils the pupil distance.
        * :attr:`distance_mm` changes only once :data:`MIN_SAMPLES` samples are in and they
          agree (:func:`snellen.geometry.steady_distance_mm`).
        """
        if self.phase is ChartPhase.TESTING and not self.live_tracking:
            return  # size held for this eye
        if self.phase is ChartPhase.COVER and self.ready_to_cover:
            return  # locked: covering an eye now would spoil the both-eyes distance
        sample = None
        if reading is not None:
            if self.phase is ChartPhase.TESTING:
                sample = self._one_eye_distance_mm(reading, self.eye)
            elif reading.ipd_px:
                sample = viewing_distance_mm(reading.ipd_px, self.calibration)
                one_eye = self._one_eye_distance_mm(reading, self.eye)
                if self.phase is ChartPhase.COVER and one_eye is not None:
                    self._agreement.append(one_eye / sample)
        if sample is None:
            self._frames_without_distance += 1
            self.holding = self.distance_mm is not None
            return
        self._frames_without_distance = 0
        self._cover_frames += self.phase is ChartPhase.COVER
        self._samples.append(sample)
        if len(self._samples) < MIN_SAMPLES:
            self.holding = False
            return
        steady = steady_distance_mm(self._samples)
        self.holding = steady is None
        if steady is not None:
            self.distance_mm = steady

    @property
    def ready_to_cover(self) -> bool:
        """bool: The both-eyes distance is known and enough frames have been compared.

        The test for the current eye can start (SPACE) only once this is true.
        """
        return self.distance_mm is not None and self._cover_frames >= AGREEMENT_FRAMES

    def _one_eye_agrees(self) -> bool:
        """Whether the one-eye distance agreed with the both-eyes one before covering.

        Returns
        -------
        bool
            True if :data:`AGREEMENT_FRAMES` ratios were recorded and their median is within
            :data:`MAX_DISAGREEMENT` of 1.
        """
        if len(self._agreement) < AGREEMENT_FRAMES:
            return False
        return abs(median(self._agreement) - 1) <= MAX_DISAGREEMENT

    def choose(self, index: int) -> None:
        """Pick the chart type on the choice page.

        Parameters
        ----------
        index : int
            Position in :attr:`optotypes` (0 for the first). Out-of-range choices, and
            choices outside the ``CHOOSE`` phase, are ignored.
        """
        if self.phase is ChartPhase.CHOOSE and 0 <= index < len(self.optotypes):
            self.optotype = self.optotypes[index]
            self.phase = ChartPhase.INSTRUCT

    def press(self, key: str) -> None:
        """Handle a key press by name.

        ``"space"`` moves on (or means "can't tell" during the test; see
        :meth:`advance`). On the choice page, ``"1"``, ``"2"``... pick a chart. During
        the test, the chosen optotype decides what other keys mean: an arrow for the E
        and the Landolt C, a letter for letters. Anything else is ignored.

        Parameters
        ----------
        key : str
            The key's name, as :func:`snellen.ui.key_name` gives it.
        """
        if key == "space":
            self.advance()
        elif self.phase is ChartPhase.CHOOSE and key.isdigit():
            self.choose(int(key) - 1)
        elif self.phase is ChartPhase.TESTING and self.optotype is not None:
            symbol = self.optotype.symbol_for_key(key)
            if symbol is not None:
                self.answer(symbol)

    def advance(self) -> None:
        """Handle SPACE.

        Moves from the instructions to covering, from covering to testing (once
        :attr:`ready_to_cover`), and from the results to finished. During the test, SPACE
        means "can't tell" and is recorded as a wrong answer.
        """
        if self.phase is ChartPhase.INSTRUCT:
            self._start_cover()
        elif self.phase is ChartPhase.COVER and self.ready_to_cover:
            self.live_tracking = self._one_eye_agrees()
            self._samples.clear()
            assert self.optotype is not None
            self.test = AcuityTest(self._rng, symbols=self.optotype.symbols)
            self.phase = ChartPhase.TESTING
            self._check_screen_limit()
        elif self.phase is ChartPhase.TESTING:
            self.answer(None)
        elif self.phase is ChartPhase.RESULTS:
            self.finished = True

    def _start_cover(self) -> None:
        """Begin the ``COVER`` phase for the current eye, clearing the distance samples."""
        self.phase = ChartPhase.COVER
        self.test = None
        self._agreement.clear()
        self._samples.clear()
        self._cover_frames = 0
        self.live_tracking = False

    def answer(self, symbol: Symbol | None) -> None:
        """Record what the user says the current optotype is.

        Parameters
        ----------
        symbol : Symbol or None
            Their answer (an E direction or a letter), or ``None`` for "can't tell".
            Ignored outside the ``TESTING`` phase.
        """
        if self.phase is not ChartPhase.TESTING or self.test is None:
            return
        self.test.answer(symbol)
        self._check_screen_limit()

    def _check_screen_limit(self) -> None:
        """End the current eye's test if its line is too small to draw, and move on when done.

        When an eye finishes, its result is stored, and the screen moves to the next eye's
        ``COVER`` phase, or to ``RESULTS`` after the last eye.
        """
        assert self.test is not None
        if not self.test.finished and self.distance_mm is not None:
            smallest = smallest_renderable_denominator(self.distance_mm, self.px_per_mm)
            if smallest is None or self.test.denominator < smallest:
                self.test.stop_at_screen_limit()
        if self.test.finished:
            self.results[self.eye] = self.test.result()
            if self._eye_index + 1 < len(EYE_ORDER):
                self._eye_index += 1
                self._start_cover()
            else:
                self.phase = ChartPhase.RESULTS

    def lines(self) -> list[str]:
        """Body text for the choice, instructions, covering and results phases.

        Returns
        -------
        list of str
            Lines to draw, top to bottom. The results include each eye's Snellen and logMAR
            score and a suggestion to see an optometrist if either eye is worse than 20/40.
        """
        if self.phase is ChartPhase.CHOOSE:
            return [
                "Which chart would you like? Press its number.",
                *(f"{i}. {o.name}: {o.how_to_answer}" for i, o in enumerate(self.optotypes, 1)),
                "",
                "Esc to quit.  " + DISCLAIMER,
            ]
        if self.phase is ChartPhase.INSTRUCT:
            assert self.optotype is not None
            return [
                "Sit about 1 m from the screen, facing it, with the keyboard in reach.",
                "Each eye is tested on its own.",
                f"{self.optotype.how_to_answer} Guess if unsure.",
                "Letters resize as you move; keep glasses on if you wear them for distance.",
                "Press SPACE to start.",
                "",
                "Esc to quit.  " + DISCLAIMER,
            ]
        if self.phase is ChartPhase.COVER:
            covered = _other(self.eye).value
            lines = [
                f"Testing your {self.eye.value} eye.",
                f"You'll cover your {covered} eye with your palm (without pressing on it).",
            ]
            if not self.ready_to_cover:
                lines.append("Look at the camera with both eyes open...")
            else:
                assert self.distance_mm is not None
                lines.append(
                    f"Distance {self.distance_mm / 1000:.2f} m. Cover your {covered} eye "
                    "and press SPACE to begin."
                )
            return lines
        assert self.optotype is not None
        lines = [f"Results with {self.optotype.name} (screening only, not a diagnosis):"]
        for eye in EYE_ORDER:
            lines.append(f"{eye.value.capitalize()} eye: {self.results[eye].describe()}")
        lines += [
            "Worse than 20/40 in either eye, or a big difference between eyes:",
            "consider seeing an optometrist.",
            "Press SPACE to finish.",
        ]
        return lines

    def status(self) -> str:
        """The status line shown along the bottom during the test.

        Returns
        -------
        str
            Eye, current line, distance, whether the size is tracking or held, and the keys.
        """
        distance = "-" if self.distance_mm is None else f"{self.distance_mm / 1000:.2f} m"
        mode = "tracking" if self.live_tracking else "size held"
        assert self.test is not None
        return (
            f"{self.eye.value.capitalize()} eye  |  20/{self.test.denominator}  |  "
            f"{distance} ({mode})  |  SPACE: can't tell"
        )

    def warning(self) -> str | None:
        """A problem worth telling the user about during the test.

        Returns
        -------
        str or None
            A message if the face can't be seen or the user should hold still, otherwise
            ``None``. There is never a warning when the size is held on purpose.
        """
        if not self.live_tracking:
            return None
        if self.face_lost:
            return "Can't see your face - letter size held. Face the camera."
        if self.holding:
            return "Hold still - letter size held."
        return None
