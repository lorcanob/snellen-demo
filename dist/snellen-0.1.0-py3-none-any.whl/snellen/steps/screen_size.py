"""Screen size step: the logic behind :mod:`snellen.screen_size_screen`, with no pygame.

Letter sizes depend on the screen's pixel density, so this step either confirms the
known density (from the hardware or a saved measurement) or measures it with a bank
card against a "christmas tree" of bars:

1. **Coarse:** :data:`COARSE_ROWS` bars, one for each density from 2.5 to 9 px/mm,
   each as long as a card would be on such a screen. The user holds the card's long
   edge against the screen, left end on the guide line, and picks the closest bar.
2. **Fine:** :data:`FINE_ROWS` bars 1% apart around that pick. The arrow keys also
   lengthen or shorten the chosen bar a pixel at a time.

The density is then the chosen bar's width divided by the card's 85.6 mm.

This is a screening toy, not a diagnostic tool.
"""

from enum import Enum, auto

from snellen.geometry import CREDIT_CARD_WIDTH_MM, card_ladder_widths_px, ladder_around_px
from snellen.measurements import ScreenRecord
from snellen.steps import DISCLAIMER

COARSE_ROWS = 12
"""Bars in the first ladder (about 12% apart)."""

FINE_ROWS = 13
"""±6% in 1% steps: covers the gap halfway to each neighbouring coarse bar (12% apart)."""

COARSE_PX_PER_MM = (2.5, 9.0)
"""Densities the first ladder spans: large monitors (~3) to laptops at 1:1 (~9)."""

FINE_STEP = 0.01
"""Width step between bars in the second ladder (1%)."""

MAX_BAR_SHARE = 0.8
"""Widest coarse bar as a share of the window width (fine bars reach 6% further)."""


class SizePhase(Enum):
    """Where the screen size step is.

    Attributes
    ----------
    DETECTED
        Showing a known density, offering to accept it or measure with a card.
    COARSE
        First ladder: wide range, coarse steps.
    FINE
        Second ladder: 1% steps around the coarse pick.
    """

    DETECTED = auto()
    COARSE = auto()
    FINE = auto()


class ScreenSizeStep:
    """State of the screen size step, with no pygame, so it can be tested directly.

    Parameters
    ----------
    known : ScreenRecord or None
        A density from the hardware or a saved measurement. If ``None``, the step starts
        straight on the coarse ladder.
    window_w_px : int
        Window width, so no bar is wider than :data:`MAX_BAR_SHARE` of it.

    Attributes
    ----------
    phase : SizePhase
        Current phase.
    widths_px : list of float
        Bar widths in the current ladder, shortest first; empty in ``DETECTED``.
    selected : int
        Index of the highlighted bar.
    result : ScreenRecord or None
        The chosen density, once picked; the loop then returns it.
    """

    def __init__(self, known: ScreenRecord | None, window_w_px: int) -> None:
        """Start on the detected density, or straight on the coarse ladder if none is known.

        See the class docstring for the parameters.
        """
        self.known = known
        self.result: ScreenRecord | None = None
        low, high = COARSE_PX_PER_MM
        high = min(high, MAX_BAR_SHARE * window_w_px / CREDIT_CARD_WIDTH_MM)
        self._coarse = card_ladder_widths_px(low, high, COARSE_ROWS)
        self._coarse_selected = COARSE_ROWS // 2
        self.widths_px: list[float] = []
        self.selected = 0
        if known is None:
            self._start_coarse()
        else:
            self.phase = SizePhase.DETECTED

    def _start_coarse(self) -> None:
        """Show the coarse ladder with the previous (or default) coarse bar highlighted."""
        self.phase = SizePhase.COARSE
        self.widths_px = list(self._coarse)
        self.selected = self._coarse_selected

    def measure(self) -> None:
        """Switch from the detected density to measuring with a card (key M).

        The coarse bar closest to the detected density is highlighted, so if the hardware
        was right, its bar should already match the card.
        """
        if self.phase is not SizePhase.DETECTED:
            return
        assert self.known is not None
        target = self.known.px_per_mm * CREDIT_CARD_WIDTH_MM
        self._coarse_selected = min(range(COARSE_ROWS), key=lambda i: abs(self._coarse[i] - target))
        self._start_coarse()

    def move(self, rows: int) -> None:
        """Move the highlight up or down the ladder, stopping at the ends.

        Parameters
        ----------
        rows : int
            Rows to move: negative is up (shorter bars), positive is down.
        """
        if self.widths_px:
            self.selected = max(0, min(len(self.widths_px) - 1, self.selected + rows))

    def nudge(self, px: int) -> None:
        """Lengthen or shorten the highlighted bar by whole pixels (fine ladder only).

        Parameters
        ----------
        px : int
            Pixels to add (negative to remove). The bar never gets shorter than 1 px.
        """
        if self.phase is SizePhase.FINE:
            self.widths_px[self.selected] = max(1.0, self.widths_px[self.selected] + px)

    def confirm(self) -> None:
        """Handle Enter or SPACE.

        Accepts the detected density, moves from the coarse to the fine ladder, or finishes
        on the highlighted fine bar and sets :attr:`result`.
        """
        if self.phase is SizePhase.DETECTED:
            self.result = self.known
        elif self.phase is SizePhase.COARSE:
            self._coarse_selected = self.selected
            self.phase = SizePhase.FINE
            self.widths_px = ladder_around_px(self._coarse[self.selected], FINE_STEP, FINE_ROWS)
            self.selected = FINE_ROWS // 2
        else:
            width_px = self.widths_px[self.selected]
            self.result = ScreenRecord(width_px / CREDIT_CARD_WIDTH_MM, "card")

    def back(self) -> None:
        """Go back from the fine ladder to the coarse one (Backspace)."""
        if self.phase is SizePhase.FINE:
            self._start_coarse()

    def press(self, key: str) -> None:
        """Handle a key press by name.

        ``"up"``/``"down"`` move the highlight, ``"left"``/``"right"`` nudge the bar
        (fine ladder), ``"return"``, ``"enter"`` or ``"space"`` confirm,
        ``"backspace"`` goes back to the coarse ladder, and ``"m"`` measures instead
        of accepting the detected value. Other keys are ignored.

        Parameters
        ----------
        key : str
            The key's name, as :func:`snellen.ui.key_name` gives it.
        """
        actions = {
            "up": lambda: self.move(-1),
            "down": lambda: self.move(1),
            "left": lambda: self.nudge(-1),
            "right": lambda: self.nudge(1),
            "return": self.confirm,
            "enter": self.confirm,
            "space": self.confirm,
            "backspace": self.back,
            "m": self.measure,
        }
        if key in actions:
            actions[key]()

    def lines(self) -> list[str]:
        """Instruction text for the current phase.

        Returns
        -------
        list of str
        """
        if self.phase is SizePhase.DETECTED:
            assert self.known is not None
            return [
                f"Your screen has {self.known.px_per_mm:.2f} pixels per mm ({self.known.source}).",
                "Letter sizes depend on this, so it's worth checking once with a bank card.",
                "SPACE to continue, M to measure with a card.",
                "",
                "Esc to quit.  " + DISCLAIMER,
            ]
        if self.phase is SizePhase.COARSE:
            return [
                "Hold a bank card's long edge against the screen, left end on the line.",
                "Up/Down: pick the bar closest to the card's length. Enter: next.",
            ]
        return [
            "Same again, closer together. Left/Right: lengthen or shorten by a pixel.",
            "Enter: done.  Backspace: back to the first set.",
        ]
