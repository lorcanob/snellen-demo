"""Screen size screen for the Snellen screening toy: draws the bank-card "christmas
tree" and runs its event loop.

The logic (confirming a known density, or picking bars on a coarse then a fine ladder)
is :class:`snellen.steps.screen_size.ScreenSizeStep`, which has no pygame; see that
module for how the measurement works.

This is a screening toy, not a diagnostic tool.
"""

import pygame

from snellen.measurements import ScreenRecord
from snellen.steps.screen_size import ScreenSizeStep, SizePhase
from snellen.ui import (
    ACCENT,
    BACKGROUND,
    MUTED,
    TEXT,
    Events,
    Tick,
    draw_text_page,
    frame_clock,
    is_quit,
    key_name,
)


def draw_screen_size(surface: pygame.Surface, step: ScreenSizeStep) -> list[pygame.Rect]:
    """Render the screen size step.

    Parameters
    ----------
    surface : pygame.Surface
        Where to draw.
    step : ScreenSizeStep
        The state to show.

    Returns
    -------
    list of pygame.Rect
        The bars drawn, in ladder order (empty in ``DETECTED``). Each bar is exactly
        ``round(width_px)`` pixels wide, starting on the guide line.
    """
    if step.phase is SizePhase.DETECTED:
        lines = step.lines()
        draw_text_page(surface, "Screen size", lines, [TEXT] * (len(lines) - 1) + [MUTED])
        return []

    title_font, body_font = pygame.font.Font(None, 44), pygame.font.Font(None, 28)
    surface.fill(BACKGROUND)
    margin = surface.get_width() // 20
    y = 24
    surface.blit(title_font.render("Measure the screen", True, TEXT), (margin, y))
    y += 44
    for line in step.lines():
        surface.blit(body_font.render(line, True, MUTED), (margin, y))
        y += 26
    y += 14

    x0 = margin + 40  # room for row numbers
    row_h = min(44, (surface.get_height() - y - 16) // len(step.widths_px))
    bar_h = max(4, row_h * 3 // 5)
    rects = []
    for i, width_px in enumerate(step.widths_px):
        selected = i == step.selected
        top = y + i * row_h
        rect = pygame.Rect(x0, top, round(width_px), bar_h)
        pygame.draw.rect(surface, ACCENT if selected else MUTED, rect)
        label = body_font.render(str(i + 1), True, TEXT if selected else MUTED)
        surface.blit(label, (margin, top + (bar_h - label.get_height()) // 2))
        if selected:
            marker = body_font.render("<", True, ACCENT)
            surface.blit(marker, (rect.right + 10, top + (bar_h - marker.get_height()) // 2))
        rects.append(rect)
    # The line the card's left end sits on.
    pygame.draw.line(surface, TEXT, (x0, y - 8), (x0, y + len(step.widths_px) * row_h), 1)
    return rects


def run_screen_size(
    surface: pygame.Surface,
    known: ScreenRecord | None,
    *,
    get_events: Events = pygame.event.get,
    tick: Tick | None = None,
) -> ScreenRecord | None:
    """Run the screen size step until a density is chosen or the user quits.

    Keys: Up/Down move the highlight, Left/Right nudge the bar (fine ladder), Enter or
    SPACE confirm, Backspace returns to the coarse ladder, M measures instead of
    accepting the detected value, and Esc quits.

    Parameters
    ----------
    surface : pygame.Surface
        The window to draw on.
    known : ScreenRecord or None
        A density from the hardware or a saved measurement, if any.
    get_events : callable, optional
        Returns the pending pygame events; ``pygame.event.get`` by default.
    tick : callable, optional
        Called once per frame to pace the loop; 30 fps by default.

    Returns
    -------
    ScreenRecord or None
        The chosen density, or ``None`` if the user closed the window or pressed Esc.
    """
    tick = frame_clock(tick)
    step = ScreenSizeStep(known, surface.get_width())
    while True:
        for event in get_events():
            if is_quit(event):
                return None
            if event.type == pygame.KEYDOWN:
                step.press(key_name(event))
        if step.result is not None:
            return step.result
        draw_screen_size(surface, step)
        pygame.display.flip()
        tick()
