"""Developer tool: a live camera view with the card and pupil detectors drawn on top.

This is for checking detection on real frames, not for end users.

Usage
-----
Live view::

    uv run python -m snellen.debug

The picture is mirrored, like a selfie camera, so moving your hand left moves it left
on screen; press M to switch between mirrored and the camera's own view. Only the
display is flipped: detection, saved frames and replay all use the unflipped frame.

The card outline is drawn in green, and each pupil gets a blue circle labelled with
the subject's eye (L/R). The strip underneath shows the frame size, fps, detection
rates, and each eye's nose and iris spans (in mm when the card is in view). Press S
to save the raw frame to ``captures/`` (or ``$SNELLEN_CAPTURE_DIR``) and Esc to quit.

Replay saved frames::

    uv run python -m snellen.debug --replay captures/

This runs the detectors on every ``.png`` in the folder and prints only the
measurements, so results can be shared without sharing face images.
"""

import os
import sys
import time
from collections import deque
from collections.abc import Callable, Iterable
from datetime import datetime
from pathlib import Path
from typing import Protocol

import cv2
import numpy as np
import pygame

from snellen import model_path_or_exit, open_tracker_or_exit
from snellen.geometry import feature_width_mm, mirror_point_px
from snellen.measurements import Detection, Reading
from snellen.tracker import Tracker, open_landmarker

WINDOW_SIZE_PX = (1280, 800)
"""Debug window size: room for a 16:9 camera image plus the stats strip."""

PANEL_HEIGHT_PX = 110
"""Text strip under the camera image."""

STATS_WINDOW = 30
"""Frames the hit rates and fps are averaged over (about 1 s)."""

CARD_COLOUR = (40, 220, 90)
"""Card outline and label (green)."""

PUPIL_COLOUR = (40, 160, 255)
"""Pupil circles and L/R labels (blue)."""

PANEL_BG = (20, 20, 20)
PANEL_TEXT = (235, 235, 235)
"""Stats strip background and text."""


class FrameSource(Protocol):
    """Anything that gives frames and detects things in them, like a Tracker."""

    def grab(self) -> np.ndarray | None:
        """The next BGR frame, or ``None`` if the camera gave none."""
        ...

    def detect(self, frame_bgr: np.ndarray) -> Detection:
        """Everything found in a frame."""
        ...


class DebugStats:
    """Rolling detection rates, frame rate and missing-picture count for the debug view.

    Parameters
    ----------
    window : int, optional
        Frames the rates and fps are averaged over. Default :data:`STATS_WINDOW`.
    now : callable, optional
        Monotonic clock in seconds; ``time.monotonic`` by default.

    Attributes
    ----------
    no_picture : int
        Loop iterations where the camera gave no frame (counted over the whole run).
    frame_size_px : tuple of int or None
        Size of the latest frame.
    """

    def __init__(self, window: int = STATS_WINDOW, now: Callable[[], float] = time.monotonic):
        """Start with empty statistics.

        See the class docstring for the parameters.
        """
        self._now = now
        self._hits: deque[tuple[bool, bool]] = deque(maxlen=window)
        self._times: deque[float] = deque(maxlen=window)
        self.no_picture = 0
        self.frame_size_px: tuple[int, int] | None = None

    def record(self, detection: Detection | None, frame_size_px: tuple[int, int] | None) -> None:
        """Add one loop iteration.

        Parameters
        ----------
        detection : Detection or None
            What was found, or ``None`` if the camera gave no frame.
        frame_size_px : tuple of int or None
            ``(width, height)`` of the frame.
        """
        self._times.append(self._now())
        if detection is None:
            self.no_picture += 1
            return
        self.frame_size_px = frame_size_px
        self._hits.append((detection.card is not None, detection.pupils_px is not None))

    @property
    def card_rate(self) -> float:
        """float: Share (0 to 1) of recent frames in which a card was found."""
        return sum(card for card, _ in self._hits) / len(self._hits) if self._hits else 0.0

    @property
    def eyes_rate(self) -> float:
        """float: Share (0 to 1) of recent frames in which both pupils were found."""
        return sum(eyes for _, eyes in self._hits) / len(self._hits) if self._hits else 0.0

    @property
    def fps(self) -> float:
        """float: Loop iterations per second over the recent window (0 until there are two)."""
        if len(self._times) < 2 or self._times[-1] == self._times[0]:
            return 0.0
        return (len(self._times) - 1) / (self._times[-1] - self._times[0])


def spans_text(reading: Reading) -> str:
    """Describe the one-eye spans for the debug panel and replay output.

    Parameters
    ----------
    reading : Reading
        A frame's measurements.

    Returns
    -------
    str
        Each eye's nose and iris spans in pixels, also in mm when a card is in view
        (the card then gives the scale), and ``-`` for spans not found.
    """

    def size(span_px: float | None) -> str:
        """One span as text: ``-``, ``"75.0 px"`` or ``"75.0 px (32.1 mm)"``."""
        if span_px is None:
            return "-"
        if reading.card_width_px:
            return f"{span_px:.1f} px ({feature_width_mm(span_px, reading.card_width_px):.1f} mm)"
        return f"{span_px:.1f} px"

    return (
        f"left eye: nose {size(reading.left_nose_px)}, iris {size(reading.left_iris_px)}   "
        f"right eye: nose {size(reading.right_nose_px)}, iris {size(reading.right_iris_px)}"
    )


def save_frame(frame_bgr: np.ndarray, directory: Path) -> Path:
    """Save a raw camera frame as a lossless PNG.

    Parameters
    ----------
    frame_bgr : numpy.ndarray
        BGR frame.
    directory : pathlib.Path
        Folder to save into; created if needed.

    Returns
    -------
    pathlib.Path
        The new file, named by timestamp, with a numeric suffix if needed so nothing is
        overwritten.
    """
    directory.mkdir(parents=True, exist_ok=True)
    stem = datetime.now().strftime("frame-%Y%m%d-%H%M%S-%f")
    path = directory / f"{stem}.png"
    n = 1
    while path.exists():
        path = directory / f"{stem}-{n}.png"
        n += 1
    cv2.imwrite(str(path), frame_bgr)
    return path


def draw_debug(
    surface: pygame.Surface,
    frame_bgr: np.ndarray | None,
    detection: Detection | None,
    stats: DebugStats,
    saved: Path | None = None,
    *,
    mirror: bool = True,
) -> None:
    """Draw the camera image scaled to fit, the detector overlay, and the stats strip.

    Parameters
    ----------
    surface : pygame.Surface
        The window.
    frame_bgr : numpy.ndarray or None
        The latest frame, or ``None`` to show "No camera picture".
    detection : Detection or None
        What was found in the frame.
    stats : DebugStats
        Rolling statistics to show.
    saved : pathlib.Path, optional
        The last saved frame, to confirm the save.
    mirror : bool, optional
        Show the picture flipped left-right, like a selfie camera, with the overlay
        flipped to match. Default True.
    """
    surface.fill(PANEL_BG)
    area_w, area_h = surface.get_width(), surface.get_height() - PANEL_HEIGHT_PX
    font = pygame.font.Font(None, 28)

    if frame_bgr is None:
        text = pygame.font.Font(None, 48).render("No camera picture", True, PANEL_TEXT)
        surface.blit(text, text.get_rect(center=(area_w // 2, area_h // 2)))
    else:
        h, w = frame_bgr.shape[:2]
        scale = min(area_w / w, area_h / h)
        offset = ((area_w - w * scale) / 2, (area_h - h * scale) / 2)
        shown = frame_bgr[:, ::-1] if mirror else frame_bgr
        rgb = np.ascontiguousarray(shown[:, :, ::-1])
        image = pygame.image.frombuffer(rgb.tobytes(), (w, h), "RGB")
        image = pygame.transform.smoothscale(image, (round(w * scale), round(h * scale)))
        surface.blit(image, (round(offset[0]), round(offset[1])))

        def to_screen(p: tuple[float, float]) -> tuple[float, float]:
            """Map a camera-image point to window coordinates (mirrored if the image is)."""
            x, y = mirror_point_px(p, w) if mirror else p
            return offset[0] + x * scale, offset[1] + y * scale

        if detection and detection.card:
            pygame.draw.polygon(
                surface, CARD_COLOUR, [to_screen(c) for c in detection.card.corners_px], width=3
            )
            label = font.render(f"card {detection.card.width_px:.1f} px", True, CARD_COLOUR)
            # Above the card's top-left corner as shown (top edge first, then leftmost).
            corners = [to_screen(c) for c in detection.card.corners_px]
            top_x, top_y = min(corners, key=lambda c: (round(c[1]), c[0]))
            surface.blit(label, (top_x, top_y - label.get_height() - 6))
        if detection and detection.pupils_px:
            # Mesh order: subject's right eye first (image left on an unmirrored camera).
            # Labels stay with their pupils, so they're right whether mirrored or not.
            for pupil, name in zip(detection.pupils_px, ("R", "L"), strict=True):
                x, y = to_screen(pupil)
                pygame.draw.circle(surface, PUPIL_COLOUR, (x, y), 6, width=2)
                label = font.render(name, True, PUPIL_COLOUR)
                surface.blit(label, (x - label.get_width() // 2, y + 10))

    size = "x".join(map(str, stats.frame_size_px)) if stats.frame_size_px else "-"
    rates = f"last {STATS_WINDOW} frames: card {stats.card_rate:.0%}, eyes {stats.eyes_rate:.0%}"
    lines = [
        f"{size}   {stats.fps:.0f} fps   no picture: {stats.no_picture}   {rates}",
        spans_text(detection.reading()) if detection else "",
        (
            f"S: save frame   M: mirror ({'on' if mirror else 'off'})   Esc: quit   "
            f"{f'saved {saved}' if saved else ''}"
        ),
    ]
    y = area_h + 12
    for line in lines:
        text = font.render(line, True, PANEL_TEXT)
        surface.blit(text, (16, y))
        y += text.get_height() + 8


def run_debug(
    surface: pygame.Surface,
    tracker: FrameSource,
    capture_dir: Path,
    *,
    get_events: Callable[[], Iterable[pygame.event.Event]] = pygame.event.get,
    tick: Callable[[], object] | None = None,
    mirror: bool = True,
) -> list[Path]:
    """Show the live debug view until Esc or the window is closed.

    Parameters
    ----------
    surface : pygame.Surface
        The window.
    tracker : FrameSource
        Camera and detectors.
    capture_dir : pathlib.Path
        Where S saves frames.
    get_events : callable, optional
        Returns the pending pygame events; ``pygame.event.get`` by default.
    tick : callable, optional
        Called once per frame; 30 fps by default.
    mirror : bool, optional
        Start with the picture mirrored (default True); M switches it during the run.

    Returns
    -------
    list of pathlib.Path
        The frames saved during the session, unmirrored, exactly as the camera gave them.
    """
    if tick is None:
        clock = pygame.time.Clock()

        def tick() -> object:
            """Hold the loop to 30 fps."""
            return clock.tick(30)

    stats = DebugStats()
    saved: list[Path] = []
    frame: np.ndarray | None = None
    while True:
        for event in get_events():
            if event.type == pygame.QUIT:
                return saved
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return saved
            if event.type == pygame.KEYDOWN and event.key == pygame.K_m:
                mirror = not mirror
            if event.type == pygame.KEYDOWN and event.key == pygame.K_s and frame is not None:
                saved.append(save_frame(frame, capture_dir))  # the frame on screen now
        frame = tracker.grab()
        detection = None if frame is None else tracker.detect(frame)
        size = None if frame is None else (frame.shape[1], frame.shape[0])
        stats.record(detection, size)
        draw_debug(surface, frame, detection, stats, saved[-1] if saved else None, mirror=mirror)
        pygame.display.flip()
        tick()


def replay(paths: Iterable[Path], detect: Callable[[np.ndarray], Detection]) -> list[str]:
    """Run the detectors on saved frames and describe what was found.

    Parameters
    ----------
    paths : iterable of pathlib.Path
        Image files.
    detect : callable
        Detects things in a BGR frame, such as :meth:`Tracker.detect`.

    Returns
    -------
    list of str
        One line per file: card width and pupil distance in pixels, the pupil distance
        in mm when both were found, and the one-eye spans.
    """
    lines = []
    for path in paths:
        frame_bgr = cv2.imread(str(path))
        if frame_bgr is None:
            lines.append(f"{path.name}: could not read")
            continue
        reading = detect(frame_bgr).reading()
        card = f"card {reading.card_width_px:.1f} px" if reading.card_width_px else "card not found"
        eyes = f"ipd {reading.ipd_px:.1f} px" if reading.ipd_px else "eyes not found"
        line = f"{path.name}: {card}, {eyes}"
        if reading.card_width_px and reading.ipd_px:
            # Card on the forehead is at about eye depth, so it scales the pupil distance.
            line += f" -> pupil distance {feature_width_mm(reading.ipd_px, reading.card_width_px):.1f} mm"
        if reading.ipd_px:
            line += f"; {spans_text(reading)}"
        lines.append(line)
    return lines


class _NoCamera:
    """Stands in for a camera when replaying saved frames (never gives a frame)."""

    def read(self) -> tuple[bool, None]:
        """Return ``(False, None)``: no frame."""
        return False, None

    def release(self) -> None:
        """Do nothing; there is no device."""


def main() -> None:
    """Entry point: show the live debug view, or replay saved frames with ``--replay DIR``.

    Exits with status 1 if the face model or the camera is missing, or the replay folder
    holds no ``.png`` files.
    """
    if len(sys.argv) == 3 and sys.argv[1] == "--replay":
        paths = sorted(Path(sys.argv[2]).glob("*.png"))
        if not paths:
            print(f"No .png frames in {sys.argv[2]}", file=sys.stderr)
            sys.exit(1)
        with Tracker(_NoCamera(), open_landmarker(model_path_or_exit())) as tracker:
            for line in replay(paths, tracker.detect):
                print(line)
        return

    tracker = open_tracker_or_exit()
    capture_dir = Path(os.environ.get("SNELLEN_CAPTURE_DIR", "captures"))
    pygame.init()
    try:
        screen = pygame.display.set_mode(WINDOW_SIZE_PX)
        pygame.display.set_caption("Snellen camera debug")
        with tracker:
            saved = run_debug(screen, tracker, capture_dir)
    except KeyboardInterrupt:
        saved = []
    finally:
        pygame.quit()
    for path in saved:
        print(f"Saved {path}")


if __name__ == "__main__":
    main()
