"""Pure geometry for the Snellen screening toy.

All of the app's maths lives here as pure functions: no I/O, no globals, no pygame,
no camera. Every other module measures pixels or draws things and calls in here to
turn those numbers into distances and letter sizes.

The module covers four topics:

* **Pinhole-camera ranging.** An object of known real width ``W`` that appears ``w``
  pixels wide, seen by a camera with focal length ``f`` (in pixels), is at distance
  ``d = W * f / w``. Calibration runs this backwards with a bank card at a known
  distance to find ``f`` (:func:`focal_length_px`), and also measures the user's own
  face spans (pupil distance, pupil to nose bridge, iris) in mm (:func:`calibrate`).
  After that, any of those spans gives the live viewing distance
  (:func:`viewing_distance_mm`, :func:`one_eye_distance_mm`).
* **Optotype sizing.** A 20/20 letter subtends 5 arcminutes at the eye, and a
  20/``x`` letter ``x / 20`` times that. With the viewing distance and the screen's
  pixel density this gives a letter height in pixels (:func:`optotype_height_px`). The
  Tumbling E shape itself is defined on a 5 x 5 grid (:func:`tumbling_e_cells`).
* **Screen density.** Pixels per mm, from the hardware's reported size
  (:func:`px_per_mm_from_display`) or by matching a card against a ladder of bars
  (:func:`card_ladder_widths_px`, :func:`ladder_around_px`).
* **Card detection helpers.** Lines in Hesse normal form, quadrilaterals built from
  them, and plausibility checks used by :mod:`snellen.card` to find a bank card
  held on the forehead.

Conventions
-----------
Units are carried in names: ``_mm`` for millimetres, ``_px`` for pixels (camera
image pixels or screen pixels, as the context says), ``_arcmin`` for arcminutes.
Functions that take physical quantities raise :class:`ValueError` for zero,
negative, NaN or infinite inputs rather than returning nonsense.

This is a screening toy, not a diagnostic tool.
"""

import math
import statistics
from collections.abc import Sequence
from dataclasses import dataclass
from enum import Enum

SNELLEN_NUMERATOR = 20
"""Reference distance (feet) in 20/x Snellen notation."""

OPTOTYPE_ARCMIN_AT_20_20 = 5.0
"""A 20/20 letter subtends 5 arcmin (each stroke 1 arcmin)."""

SNELLEN_DENOMINATORS = (200, 100, 70, 50, 40, 30, 25, 20, 15, 10)
"""Chart lines, largest letters first (20/200 down to 20/10)."""

MIN_OPTOTYPE_HEIGHT_PX = 5.0
"""Smallest letter drawn: below 5 px a stroke (1/5 of the height) is under one pixel."""

PLAUSIBLE_PX_PER_MM = (2.0, 20.0)
"""Screen pixel densities outside this range suggest a wrong size report or measurement."""

LANDOLT_C_RADII = (2.5, 1.5)
"""Outer and inner radius of a Landolt C on the same 5 x 5 grid as the Tumbling E:
5 across, with a ring and gap both 1 wide (ISO 8596)."""

CREDIT_CARD_WIDTH_MM = 85.60
"""Long edge of an ISO/IEC 7810 ID-1 card (bank card, driving licence)."""

CREDIT_CARD_HEIGHT_MM = 53.98
"""Short edge of an ID-1 card."""

CALIBRATION_DISTANCE_MM = 6 * CREDIT_CARD_WIDTH_MM
"""Suggested eye-to-camera distance for calibration: six card lengths (513.6 mm)."""

PLAUSIBLE_IPD_MM = (45.0, 80.0)
"""Pupil distances outside this range suggest the card was not at eye depth."""

PLAUSIBLE_NOSE_SPAN_MM = (24.0, 42.0)
"""Pupil to nose bridge (about half the pupil distance); outside this the span is unusable."""

PLAUSIBLE_IRIS_MM = (9.0, 14.0)
"""Visible iris diameter (typically 11-12.5 mm); outside this the span is unusable."""

CARD_TILT_ASPECT_RANGE = (1.45, 2.4)
"""Apparent long/short ratio of a card that may lean up to ~50 degrees away from the camera
(a card on a sloping forehead, seen from a camera below eye level, looks flattened)."""

CARD_TO_IPD_RANGE = (
    CREDIT_CARD_WIDTH_MM / PLAUSIBLE_IPD_MM[1],
    CREDIT_CARD_WIDTH_MM / PLAUSIBLE_IPD_MM[0],
)
"""Card width / pupil distance (both px, about the same depth) for plausible pupil distances."""

CARD_MIN_WIDTH_FRACTION = 0.06
"""Ignore card candidates narrower than this share of the frame width."""

OPPOSITE_SIDE_MIN_RATIO = 0.8
"""Shorter / longer of each pair of opposite card sides; perspective keeps them close."""

CARD_CENTRE_MAX_OFFSET_IPD = 0.6
"""How far (in pupil distances) the card centre may sit sideways from between the eyes."""

Line = tuple[float, float, float]
"""(nx, ny, rho): the points with nx*x + ny*y == rho, where (nx, ny) is a unit normal."""

Point = tuple[float, float]
"""(x, y) in image pixels, x to the right and y downwards."""

Quad = tuple[Point, Point, Point, Point]
"""Corners clockwise from top-left: top-left, top-right, bottom-right, bottom-left."""


def _require_positive(**values: float) -> None:
    """Raise if any keyword value is not a positive, finite number.

    Parameters
    ----------
    **values : float
        Values to check, named so the error message can say which one is wrong.

    Raises
    ------
    ValueError
        If any value is zero, negative, NaN or infinite.
    """
    for name, value in values.items():
        if not (math.isfinite(value) and value > 0):
            raise ValueError(f"{name} must be a positive finite number, got {value!r}")


# --- pinhole camera and optotype sizing -------------------------------------------


def focal_length_px(width_px: float, distance_mm: float, real_width_mm: float) -> float:
    """Camera focal length from an object of known width seen at a known distance.

    Inverts the pinhole model ``width_px = focal_px * real_width_mm / distance_mm``.

    Parameters
    ----------
    width_px : float
        Apparent width of the object in the camera image, in pixels.
    distance_mm : float
        Distance from the camera to the object, in mm.
    real_width_mm : float
        True width of the object, in mm.

    Returns
    -------
    float
        Focal length in image pixels.

    Raises
    ------
    ValueError
        If any argument is not a positive finite number.

    Examples
    --------
    >>> focal_length_px(200.0, 513.6, 85.6)
    1200.0
    """
    _require_positive(width_px=width_px, distance_mm=distance_mm, real_width_mm=real_width_mm)
    return width_px * distance_mm / real_width_mm


def distance_mm(width_px: float, focal_length_px: float, real_width_mm: float) -> float:
    """Distance to an object of known width, from its apparent width in pixels.

    Parameters
    ----------
    width_px : float
        Apparent width of the object in the camera image, in pixels.
    focal_length_px : float
        Camera focal length in pixels (see :func:`focal_length_px`).
    real_width_mm : float
        True width of the object, in mm.

    Returns
    -------
    float
        Camera-to-object distance in mm.

    Raises
    ------
    ValueError
        If any argument is not a positive finite number.

    Examples
    --------
    >>> distance_mm(100.0, 1200.0, 85.6)
    1027.2
    """
    _require_positive(
        width_px=width_px, focal_length_px=focal_length_px, real_width_mm=real_width_mm
    )
    return real_width_mm * focal_length_px / width_px


def optotype_height_mm(distance_mm: float, denominator: float) -> float:
    """Physical letter height for a 20/``denominator`` line viewed from ``distance_mm``.

    A 20/20 letter subtends :data:`OPTOTYPE_ARCMIN_AT_20_20` (5 arcmin) at the eye, and
    a 20/x letter ``x / 20`` times that. The height is the chord of that angle at the
    given distance: ``2 * d * tan(angle / 2)``.

    Parameters
    ----------
    distance_mm : float
        Eye-to-letter distance in mm.
    denominator : float
        Snellen denominator: 20 for 20/20, 200 for 20/200 and so on.

    Returns
    -------
    float
        Letter height in mm.

    Raises
    ------
    ValueError
        If either argument is not a positive finite number.

    Examples
    --------
    At the standard 20 ft (6.096 m), a 20/20 letter is about 8.9 mm tall:

    >>> round(optotype_height_mm(6096.0, 20), 2)
    8.87
    """
    _require_positive(distance_mm=distance_mm, denominator=denominator)
    height_arcmin = OPTOTYPE_ARCMIN_AT_20_20 * denominator / SNELLEN_NUMERATOR
    return 2 * distance_mm * math.tan(math.radians(height_arcmin / 60) / 2)


def optotype_height_px(distance_mm: float, denominator: float, px_per_mm: float) -> float:
    """On-screen letter height for a 20/``denominator`` line viewed from ``distance_mm``.

    Parameters
    ----------
    distance_mm : float
        Eye-to-screen distance in mm.
    denominator : float
        Snellen denominator (20 for 20/20).
    px_per_mm : float
        Screen pixel density, in window pixels per mm.

    Returns
    -------
    float
        Letter height in screen pixels. Usually fractional; see
        :func:`snellen.chart_screen.tumbling_e_surface` for how that is drawn.

    Raises
    ------
    ValueError
        If any argument is not a positive finite number.

    See Also
    --------
    optotype_height_mm : the same height in mm.

    Examples
    --------
    A 20/200 letter at 1 m on a 5 px/mm screen:

    >>> round(optotype_height_px(1000.0, 200, 5.0), 1)
    72.7
    """
    return mm_to_px(optotype_height_mm(distance_mm, denominator), px_per_mm)


def smallest_renderable_denominator(distance_mm: float, px_per_mm: float) -> int | None:
    """Smallest chart line that can be drawn faithfully at this distance.

    A line can be drawn when its letters are at least :data:`MIN_OPTOTYPE_HEIGHT_PX`
    tall, so that each stroke (a fifth of the height) covers at least one pixel.

    Parameters
    ----------
    distance_mm : float
        Eye-to-screen distance in mm.
    px_per_mm : float
        Screen pixel density, in window pixels per mm.

    Returns
    -------
    int or None
        The smallest denominator in :data:`SNELLEN_DENOMINATORS` whose letters are big
        enough, or ``None`` if even the 20/200 letters are too small.

    Examples
    --------
    >>> smallest_renderable_denominator(1000.0, 5.0)  # 20/10 would be 3.6 px
    15
    >>> smallest_renderable_denominator(3000.0, 10.0)
    10
    """
    fits = [
        d
        for d in SNELLEN_DENOMINATORS
        if optotype_height_px(distance_mm, d, px_per_mm) >= MIN_OPTOTYPE_HEIGHT_PX
    ]
    return min(fits) if fits else None


class Direction(Enum):
    """Which way a Tumbling E's arms point (its open side).

    ``RIGHT`` is an ordinary letter E. The user answers with the matching arrow key.
    """

    RIGHT = "right"
    DOWN = "down"
    LEFT = "left"
    UP = "up"


def tumbling_e_cells(direction: Direction) -> list[tuple[int, int, int, int]]:
    """Rectangles making up a Tumbling E on a 5 x 5 grid.

    The E is a spine one cell thick on the side opposite ``direction``, plus three arms,
    each one cell thick, running towards ``direction``. The gaps between the arms are
    also one cell, so every stroke and gap is a fifth of the letter height, as on a
    standard chart.

    Parameters
    ----------
    direction : Direction
        The open side of the E.

    Returns
    -------
    list of tuple of int
        Four non-overlapping ``(x, y, w, h)`` rectangles in grid cells, with ``x`` to the
        right and ``y`` downwards: the spine first, then the three arms. Together they
        cover 17 of the 25 cells.

    Examples
    --------
    >>> tumbling_e_cells(Direction.RIGHT)
    [(0, 0, 1, 5), (1, 0, 4, 1), (1, 2, 4, 1), (1, 4, 4, 1)]
    """
    match direction:
        case Direction.RIGHT:
            return [(0, 0, 1, 5)] + [(1, y, 4, 1) for y in (0, 2, 4)]
        case Direction.LEFT:
            return [(4, 0, 1, 5)] + [(0, y, 4, 1) for y in (0, 2, 4)]
        case Direction.DOWN:
            return [(0, 0, 5, 1)] + [(x, 1, 1, 4) for x in (0, 2, 4)]
        case Direction.UP:
            return [(0, 4, 5, 1)] + [(x, 0, 1, 4) for x in (0, 2, 4)]


def landolt_c_gap(direction: Direction) -> tuple[float, float, float, float]:
    """The gap cut from a Landolt C's ring, as a rectangle on the 5 x 5 grid.

    Parameters
    ----------
    direction : Direction
        Which side the gap is on.

    Returns
    -------
    tuple of float
        ``(x, y, w, h)`` with ``x`` to the right and ``y`` downwards: 1 wide, running
        from the centre out past the ring on the ``direction`` side.

    Examples
    --------
    >>> landolt_c_gap(Direction.RIGHT)
    (2.5, 2.0, 2.5, 1.0)
    """
    match direction:
        case Direction.RIGHT:
            return 2.5, 2.0, 2.5, 1.0
        case Direction.LEFT:
            return 0.0, 2.0, 2.5, 1.0
        case Direction.DOWN:
            return 2.0, 2.5, 1.0, 2.5
        case Direction.UP:
            return 2.0, 0.0, 1.0, 2.5


def landolt_c_inked(x: float, y: float, direction: Direction) -> bool:
    """Whether a point on the 5 x 5 grid is inked in a Landolt C.

    The ring runs between :data:`LANDOLT_C_RADII` around the centre ``(2.5, 2.5)``,
    minus the gap from :func:`landolt_c_gap`. Edges count as inked.

    Parameters
    ----------
    x, y : float
        Grid coordinates, ``x`` to the right and ``y`` downwards, 0 to 5.
    direction : Direction
        Which side the gap is on.

    Returns
    -------
    bool

    Examples
    --------
    >>> landolt_c_inked(0.5, 2.5, Direction.RIGHT)  # on the ring, opposite the gap
    True
    >>> landolt_c_inked(4.5, 2.5, Direction.RIGHT)  # in the gap
    False
    """
    outer, inner = LANDOLT_C_RADII
    if not inner <= math.hypot(x - 2.5, y - 2.5) <= outer:
        return False
    gx, gy, gw, gh = landolt_c_gap(direction)
    return not (gx < x < gx + gw and gy < y < gy + gh)


# --- screen density ---------------------------------------------------------------


def px_per_mm_from_display(width_px: float, width_mm: float) -> float:
    """Screen pixel density from its width in pixels and in mm.

    Parameters
    ----------
    width_px : float
        Display width in window pixels (points on macOS).
    width_mm : float
        Physical display width in mm, as reported by the hardware.

    Returns
    -------
    float
        Pixels per mm.

    Raises
    ------
    ValueError
        If either argument is not positive and finite, or the density falls outside
        :data:`PLAUSIBLE_PX_PER_MM` (for example a monitor reporting a bogus size).

    Examples
    --------
    >>> round(px_per_mm_from_display(1512, 302.0), 3)
    5.007
    """
    _require_positive(width_px=width_px, width_mm=width_mm)
    density = width_px / width_mm
    low, high = PLAUSIBLE_PX_PER_MM
    if not low <= density <= high:
        raise ValueError(f"{density:.2f} px/mm is outside {low:.0f}-{high:.0f} px/mm")
    return density


def card_ladder_widths_px(lo_px_per_mm: float, hi_px_per_mm: float, rows: int) -> list[float]:
    """Bar widths for the first, coarse "christmas tree" of the screen measurement.

    Each bar is how wide a bank card would be on a screen of a particular density. The
    densities are spaced evenly in ratio (geometrically) from ``lo`` to ``hi``, so every
    step is the same relative change.

    Parameters
    ----------
    lo_px_per_mm, hi_px_per_mm : float
        Lowest and highest density to cover, in px/mm; ``lo`` must be below ``hi``.
    rows : int
        Number of bars, at least 2.

    Returns
    -------
    list of float
        ``rows`` widths in pixels, shortest first; the first is
        ``CREDIT_CARD_WIDTH_MM * lo`` and the last ``CREDIT_CARD_WIDTH_MM * hi``.

    Raises
    ------
    ValueError
        If the densities are not positive, ``lo >= hi``, or ``rows < 2``.

    Examples
    --------
    >>> [round(w) for w in card_ladder_widths_px(2.0, 8.0, 3)]
    [171, 342, 685]
    """
    _require_positive(lo_px_per_mm=lo_px_per_mm, hi_px_per_mm=hi_px_per_mm)
    if rows < 2 or hi_px_per_mm <= lo_px_per_mm:
        raise ValueError(f"need rows >= 2 and lo < hi, got {rows}, {lo_px_per_mm}, {hi_px_per_mm}")
    ratio = hi_px_per_mm / lo_px_per_mm
    return [CREDIT_CARD_WIDTH_MM * lo_px_per_mm * ratio ** (i / (rows - 1)) for i in range(rows)]


def ladder_around_px(width_px: float, step_fraction: float, rows: int) -> list[float]:
    """Bar widths for the second, fine ladder, centred on the bar chosen in the first.

    Parameters
    ----------
    width_px : float
        The middle bar's width in pixels.
    step_fraction : float
        Relative change between neighbouring bars (0.01 for 1%).
    rows : int
        Number of bars; must be odd so that ``width_px`` sits exactly in the middle.

    Returns
    -------
    list of float
        ``rows`` widths, shortest first, each ``1 + step_fraction`` times the last.

    Raises
    ------
    ValueError
        If ``width_px`` or ``step_fraction`` is not positive, or ``rows`` is not a
        positive odd number.

    Examples
    --------
    >>> [round(w, 1) for w in ladder_around_px(400.0, 0.01, 3)]
    [396.0, 400.0, 404.0]
    """
    _require_positive(width_px=width_px, step_fraction=step_fraction)
    if rows < 1 or rows % 2 == 0:
        raise ValueError(f"rows must be odd and positive, got {rows}")
    middle = rows // 2
    return [width_px * (1 + step_fraction) ** (i - middle) for i in range(rows)]


def mm_to_px(mm: float, px_per_mm: float) -> float:
    """Convert a physical length to screen pixels.

    Parameters
    ----------
    mm : float
        Length in mm.
    px_per_mm : float
        Screen pixel density.

    Returns
    -------
    float
        Length in screen pixels.

    Raises
    ------
    ValueError
        If either argument is not a positive finite number.

    Examples
    --------
    >>> mm_to_px(10.0, 5.0)
    50.0
    """
    _require_positive(mm=mm, px_per_mm=px_per_mm)
    return mm * px_per_mm


def logmar(denominator: float) -> float:
    """LogMAR acuity for a 20/``denominator`` Snellen fraction.

    LogMAR is the base-10 log of the minimum angle of resolution in arcminutes. 0.0 is
    20/20; each +0.1 is one line worse, and negative values are better than 20/20.

    Parameters
    ----------
    denominator : float
        Snellen denominator.

    Returns
    -------
    float
        ``log10(denominator / 20)``.

    Raises
    ------
    ValueError
        If ``denominator`` is not a positive finite number.

    Examples
    --------
    >>> logmar(20)
    0.0
    >>> logmar(200)
    1.0
    """
    _require_positive(denominator=denominator)
    return math.log10(denominator / SNELLEN_NUMERATOR)


def pixel_distance_px(a_px: tuple[float, float], b_px: tuple[float, float]) -> float:
    """Euclidean distance between two image points.

    Parameters
    ----------
    a_px, b_px : tuple of float
        ``(x, y)`` points in pixels.

    Returns
    -------
    float
        Straight-line distance in pixels.

    Raises
    ------
    ValueError
        If any coordinate is NaN or infinite.

    Examples
    --------
    >>> pixel_distance_px((0.0, 0.0), (3.0, 4.0))
    5.0
    """
    if not all(math.isfinite(v) for v in (*a_px, *b_px)):
        raise ValueError(f"points must be finite, got {a_px!r}, {b_px!r}")
    return math.dist(a_px, b_px)


def feature_width_mm(
    feature_px: float, card_px: float, reference_width_mm: float = CREDIT_CARD_WIDTH_MM
) -> float:
    """Real size of a feature measured at the same depth as a reference card.

    Things at the same distance from the camera share one mm-per-pixel scale, so a
    card of known width next to the eyes turns pupil or iris pixels into mm.

    Parameters
    ----------
    feature_px : float
        The feature's size in the image, in pixels.
    card_px : float
        The card's long edge in the same image, in pixels.
    reference_width_mm : float, optional
        The card's real width; defaults to :data:`CREDIT_CARD_WIDTH_MM`.

    Returns
    -------
    float
        The feature's real size in mm.

    Raises
    ------
    ValueError
        If any argument is not a positive finite number.

    Examples
    --------
    >>> feature_width_mm(147.0, 200.0)
    62.916
    """
    _require_positive(feature_px=feature_px, card_px=card_px, reference_width_mm=reference_width_mm)
    return feature_px * reference_width_mm / card_px


# --- calibration and live distance ---------------------------------------------


class Eye(Enum):
    """The subject's own left or right eye (not the side it appears on in the image)."""

    LEFT = "left"
    RIGHT = "right"


@dataclass(frozen=True)
class Calibration:
    """Camera focal length and the user's face sizes, from one calibration step.

    Produced by :func:`calibrate`, then used to turn live pixel measurements into
    viewing distances.

    Parameters
    ----------
    focal_length_px : float
        Camera focal length in image pixels.
    ipd_mm : float
        The user's interpupillary (pupil-to-pupil) distance in mm.
    left_nose_mm, right_nose_mm : float or None, optional
        Distance from each pupil to the bridge of the nose, in mm.
    left_iris_mm, right_iris_mm : float or None, optional
        Visible diameter of each iris, in mm.

    Notes
    -----
    The per-eye spans are ``None`` where they were not seen or came out implausible.
    That eye's distance then can't be tracked while the other eye is covered, so the
    chart holds the letter size instead.
    """

    focal_length_px: float
    ipd_mm: float
    left_nose_mm: float | None = None
    right_nose_mm: float | None = None
    left_iris_mm: float | None = None
    right_iris_mm: float | None = None

    def spans_mm(self, eye: Eye) -> tuple[float | None, float | None]:
        """The one-eye spans for one eye.

        Parameters
        ----------
        eye : Eye
            Which of the subject's eyes.

        Returns
        -------
        tuple of (float or None, float or None)
            ``(nose span, iris diameter)`` in mm, each ``None`` if unknown.

        Examples
        --------
        >>> Calibration(1200.0, 63.0, left_nose_mm=32.0).spans_mm(Eye.LEFT)
        (32.0, None)
        """
        if eye is Eye.LEFT:
            return self.left_nose_mm, self.left_iris_mm
        return self.right_nose_mm, self.right_iris_mm


def _span_mm(
    span_px: Sequence[float], card_px: float, plausible_mm: tuple[float, float]
) -> float | None:
    """Median of a span's frames, in mm at the card's depth.

    Parameters
    ----------
    span_px : sequence of float
        The span's size in each calibration frame, in pixels (may be empty).
    card_px : float
        Median card width in pixels.
    plausible_mm : tuple of float
        ``(low, high)`` range of believable real sizes.

    Returns
    -------
    float or None
        The size in mm, or ``None`` if there are no frames or the result is outside
        ``plausible_mm``.
    """
    if not span_px:
        return None
    mm = feature_width_mm(statistics.median(span_px), card_px)
    return mm if plausible_mm[0] <= mm <= plausible_mm[1] else None


def calibrate(
    card_px: Sequence[float],
    ipd_px: Sequence[float],
    distance_mm: float,
    *,
    left_nose_px: Sequence[float] = (),
    right_nose_px: Sequence[float] = (),
    left_iris_px: Sequence[float] = (),
    right_iris_px: Sequence[float] = (),
) -> Calibration:
    """Calibrate from frames of a card held on the forehead, ``distance_mm`` from the camera.

    The card is at about the same depth as the eyes, so it gives the mm-per-pixel scale
    for the face spans, and with the known distance it also gives the focal length. The
    median of each measurement is used, so a few bad frames don't skew the result.

    Parameters
    ----------
    card_px : sequence of float
        Card long-edge width in each frame, in pixels.
    ipd_px : sequence of float
        Pupil-to-pupil distance in each frame, in pixels.
    distance_mm : float
        The eye-to-camera distance the user was asked to sit at.
    left_nose_px, right_nose_px : sequence of float, optional
        Pupil-to-nose-bridge distance per frame for each eye, in pixels.
    left_iris_px, right_iris_px : sequence of float, optional
        Iris diameter per frame for each eye, in pixels.

    Returns
    -------
    Calibration
        Focal length, pupil distance and whichever one-eye spans were plausible.

    Raises
    ------
    ValueError
        If ``card_px`` or ``ipd_px`` is empty, any measurement is not positive and
        finite, or the pupil distance is outside :data:`PLAUSIBLE_IPD_MM` (usually the
        card wasn't flat against the forehead). The message is written to be shown to
        the user.

    Notes
    -----
    One-eye spans outside :data:`PLAUSIBLE_NOSE_SPAN_MM` or :data:`PLAUSIBLE_IRIS_MM`
    are set to ``None`` rather than failing calibration: the test still works for that
    eye, just with a held letter size.

    Examples
    --------
    >>> cal = calibrate([200.0], [147.0], 513.6)
    >>> cal.focal_length_px, round(cal.ipd_mm, 1)
    (1200.0, 62.9)
    """
    if not card_px or not ipd_px:
        raise ValueError("calibration needs at least one card and one pupil measurement")
    spans = (left_nose_px, right_nose_px, left_iris_px, right_iris_px)
    for value in (*card_px, *ipd_px, *(v for span in spans for v in span)):
        _require_positive(measurement_px=value)
    _require_positive(distance_mm=distance_mm)
    card = statistics.median(card_px)
    ipd = statistics.median(ipd_px)

    ipd_mm = feature_width_mm(ipd, card)
    low, high = PLAUSIBLE_IPD_MM
    if not low <= ipd_mm <= high:
        raise ValueError(
            f"pupil distance {ipd_mm:.1f} mm is outside {low:.0f}-{high:.0f} mm; "
            "hold the card flat against your forehead, just above your eyes"
        )
    return Calibration(
        focal_length_px=focal_length_px(card, distance_mm, CREDIT_CARD_WIDTH_MM),
        ipd_mm=ipd_mm,
        left_nose_mm=_span_mm(left_nose_px, card, PLAUSIBLE_NOSE_SPAN_MM),
        right_nose_mm=_span_mm(right_nose_px, card, PLAUSIBLE_NOSE_SPAN_MM),
        left_iris_mm=_span_mm(left_iris_px, card, PLAUSIBLE_IRIS_MM),
        right_iris_mm=_span_mm(right_iris_px, card, PLAUSIBLE_IRIS_MM),
    )


def viewing_distance_mm(ipd_px: float, calibration: Calibration) -> float:
    """Current eye-to-camera distance from the pupil distance measured in pixels.

    Parameters
    ----------
    ipd_px : float
        Pupil-to-pupil distance in the current frame, in pixels.
    calibration : Calibration
        The user's calibration (focal length and real pupil distance).

    Returns
    -------
    float
        Distance in mm.

    Raises
    ------
    ValueError
        If ``ipd_px`` is not a positive finite number.

    Examples
    --------
    >>> round(viewing_distance_mm(75.6, Calibration(1200.0, 63.0)))
    1000
    """
    return distance_mm(ipd_px, calibration.focal_length_px, calibration.ipd_mm)


def one_eye_distance_mm(
    nose_px: float | None,
    iris_px: float | None,
    nose_mm: float | None,
    iris_mm: float | None,
    focal_px: float,
) -> float | None:
    """Eye-to-camera distance from spans that need only one eye visible.

    Used while the other eye is covered, when the pupil distance is unreliable. Each
    span that was both seen (px) and calibrated (mm) gives a distance. The distances
    are averaged, weighted by span length in pixels, because a landmark's jitter
    matters less on a longer span.

    Parameters
    ----------
    nose_px, iris_px : float or None
        The open eye's pupil-to-nose-bridge and iris spans in this frame, in pixels.
    nose_mm, iris_mm : float or None
        The same spans' real sizes from calibration, in mm.
    focal_px : float
        Camera focal length in pixels.

    Returns
    -------
    float or None
        Distance in mm, or ``None`` if no span is both seen and calibrated. Spans that
        are zero, negative or not finite are ignored.

    Examples
    --------
    >>> one_eye_distance_mm(28.8, 10.8, 32.0, 12.0, focal_px=900.0)
    1000.0
    >>> one_eye_distance_mm(None, None, 32.0, 12.0, focal_px=900.0) is None
    True
    """
    estimates = [
        (span_px, distance_mm(span_px, focal_px, span_mm))
        for span_px, span_mm in ((nose_px, nose_mm), (iris_px, iris_mm))
        if span_px is not None and span_mm is not None and math.isfinite(span_px) and span_px > 0
    ]
    if not estimates:
        return None
    return sum(w * d for w, d in estimates) / sum(w for w, _ in estimates)


def steady_distance_mm(
    samples_mm: Sequence[float], max_change: float = 0.08, min_share: float = 0.7
) -> float | None:
    """A distance worth sizing letters by, or ``None`` if the tracking is jumping about.

    Parameters
    ----------
    samples_mm : sequence of float
        Recent distance estimates in mm (for example the last half second).
    max_change : float, optional
        How far a sample may be from the median and still count as agreeing, as a
        fraction of the median. Default 0.08 (8%).
    min_share : float, optional
        Fraction of samples that must agree. Default 0.7.

    Returns
    -------
    float or None
        The median of the samples, or ``None`` if there are none or fewer than
        ``min_share`` of them agree. In that case the caller should keep the letters at
        their current size.

    Examples
    --------
    >>> steady_distance_mm([1000.0, 1010.0, 990.0, 1005.0, 3000.0])
    1005.0
    >>> steady_distance_mm([600.0, 1000.0, 1400.0]) is None
    True
    """
    if not samples_mm:
        return None
    median = statistics.median(samples_mm)
    close = sum(abs(d - median) <= max_change * median for d in samples_mm)
    return median if close >= min_share * len(samples_mm) else None


# --- lines and card quadrilaterals (used by the tracker's card detector) ------------


def line_intersection_px(a: Line, b: Line) -> Point | None:
    """Where two lines cross.

    Parameters
    ----------
    a, b : Line
        Lines in ``(nx, ny, rho)`` form.

    Returns
    -------
    Point or None
        The crossing point, or ``None`` if the lines are (nearly) parallel.

    Examples
    --------
    >>> line_intersection_px((1.0, 0.0, 3.0), (0.0, 1.0, 4.0))  # x = 3 and y = 4
    (3.0, 4.0)
    """
    det = a[0] * b[1] - a[1] * b[0]
    if abs(det) < 1e-6:
        return None
    return (a[2] * b[1] - a[1] * b[2]) / det, (a[0] * b[2] - a[2] * b[0]) / det


def quad_from_lines(top: Line, bottom: Line, left: Line, right: Line) -> Quad | None:
    """Corners of the quadrilateral bounded by four lines.

    Parameters
    ----------
    top, bottom, left, right : Line
        The four sides.

    Returns
    -------
    Quad or None
        Corners clockwise from top-left, or ``None`` if any adjacent pair of sides is
        parallel.

    Examples
    --------
    >>> quad_from_lines((0, 1, 1), (0, 1, 3), (1, 0, 1), (1, 0, 4))  # y=1, y=3, x=1, x=4
    ((1.0, 1.0), (4.0, 1.0), (4.0, 3.0), (1.0, 3.0))
    """
    corners = (
        line_intersection_px(top, left),
        line_intersection_px(top, right),
        line_intersection_px(bottom, right),
        line_intersection_px(bottom, left),
    )
    if any(c is None for c in corners):
        return None
    return corners  # type: ignore[return-value]


def _side_lengths_px(quad: Quad) -> tuple[float, float, float, float]:
    """Top, right, bottom and left side lengths of a quadrilateral, in pixels."""
    return tuple(math.dist(quad[i], quad[(i + 1) % 4]) for i in range(4))  # type: ignore[return-value]


def card_width_from_quad_px(quad: Quad) -> float:
    """A card's long edge: the mean of the longer pair of opposite sides.

    When a card leans towards or away from the camera, its two long edges are at
    different depths and so look different lengths. Their mean is the width at the
    card's centre depth.

    Parameters
    ----------
    quad : Quad
        The card's corners, clockwise from top-left.

    Returns
    -------
    float
        Long-edge width in pixels.

    Examples
    --------
    >>> card_width_from_quad_px(((0, 0), (300, 0), (300, 189), (0, 189)))
    300.0
    """
    top, right, bottom, left = _side_lengths_px(quad)
    return max((top + bottom) / 2, (left + right) / 2)


def _is_convex(quad: Quad) -> bool:
    """True if the quadrilateral is convex (every turn goes the same way)."""
    crosses = []
    for i in range(4):
        (ax, ay), (bx, by), (cx, cy) = quad[i], quad[(i + 1) % 4], quad[(i + 2) % 4]
        crosses.append((bx - ax) * (cy - by) - (by - ay) * (cx - bx))
    return all(c > 0 for c in crosses) or all(c < 0 for c in crosses)


def is_plausible_card_quad(
    quad: Quad,
    frame_w_px: float,
    ipd_px: float | None = None,
    eye_mid_px: Point | None = None,
) -> bool:
    """Could this quadrilateral be a bank card, and one held on the forehead if eyes are given?

    The shape checks are: convex; opposite sides within :data:`OPPOSITE_SIDE_MIN_RATIO`
    of each other; long/short ratio within :data:`CARD_TILT_ASPECT_RANGE`; and at least
    :data:`CARD_MIN_WIDTH_FRACTION` of the frame wide. With the eyes given, it must also
    be sized like a card next to those eyes (:data:`CARD_TO_IPD_RANGE`), centred above
    them, and no more than :data:`CARD_CENTRE_MAX_OFFSET_IPD` pupil distances to the side.

    Parameters
    ----------
    quad : Quad
        Candidate corners, clockwise from top-left.
    frame_w_px : float
        Camera frame width in pixels.
    ipd_px : float, optional
        Pupil distance in this frame, in pixels.
    eye_mid_px : Point, optional
        Point midway between the pupils.

    Returns
    -------
    bool
        Whether the candidate passes every check.
    """
    if not all(math.isfinite(v) for corner in quad for v in corner) or not _is_convex(quad):
        return False
    top, right, bottom, left = _side_lengths_px(quad)
    pairs = ((top, bottom), (left, right))
    if any(min(pair) < OPPOSITE_SIDE_MIN_RATIO * max(pair) for pair in pairs):
        return False
    long_px = max((top + bottom) / 2, (left + right) / 2)
    short_px = min((top + bottom) / 2, (left + right) / 2)
    low, high = CARD_TILT_ASPECT_RANGE
    if not low <= long_px / short_px <= high:
        return False
    if long_px < CARD_MIN_WIDTH_FRACTION * frame_w_px:
        return False
    if ipd_px is None or eye_mid_px is None:
        return True
    low, high = CARD_TO_IPD_RANGE
    if not low <= long_px / ipd_px <= high:
        return False
    centre_x = sum(x for x, _ in quad) / 4
    centre_y = sum(y for _, y in quad) / 4
    sideways_ok = abs(centre_x - eye_mid_px[0]) <= CARD_CENTRE_MAX_OFFSET_IPD * ipd_px
    return sideways_ok and centre_y < eye_mid_px[1]


def forehead_search_box_px(
    left_pupil_px: Point, right_pupil_px: Point, frame_w_px: float, frame_h_px: float
) -> tuple[float, float, float, float]:
    """The region above the eyes where a card held on the forehead must be.

    The box is 3 pupil distances wide, centred between the eyes, and runs from 2.6 to
    0.15 pupil distances above them, clipped to the frame.

    Parameters
    ----------
    left_pupil_px, right_pupil_px : Point
        The two pupil centres in the image.
    frame_w_px, frame_h_px : float
        Frame size in pixels.

    Returns
    -------
    tuple of float
        ``(x0, y0, x1, y1)``: the top-left and bottom-right corners.

    Raises
    ------
    ValueError
        If the two pupils are at the same point.
    """
    ipd = pixel_distance_px(left_pupil_px, right_pupil_px)
    _require_positive(ipd_px=ipd)
    mid_x = (left_pupil_px[0] + right_pupil_px[0]) / 2
    mid_y = (left_pupil_px[1] + right_pupil_px[1]) / 2
    return (
        max(0.0, mid_x - 1.5 * ipd),
        max(0.0, mid_y - 2.6 * ipd),
        min(float(frame_w_px), mid_x + 1.5 * ipd),
        min(float(frame_h_px), mid_y - 0.15 * ipd),
    )


def parabolic_peak_offset(left: float, centre: float, right: float) -> float:
    """Sub-sample position of a peak, from a parabola through three samples.

    Parameters
    ----------
    left, centre, right : float
        Three neighbouring samples, with the peak at ``centre``.

    Returns
    -------
    float
        Offset of the true peak from ``centre``, in samples, clamped to -0.5..0.5. Zero
        if the samples are flat or form a valley.

    Examples
    --------
    >>> round(parabolic_peak_offset(1.0, 3.0, 2.0), 3)  # peak leans right
    0.167
    >>> parabolic_peak_offset(1.0, 2.0, 2.0)
    0.5
    """
    curvature = left - 2 * centre + right
    if curvature >= 0:  # flat or a valley: no peak to refine
        return 0.0
    return max(-0.5, min(0.5, (left - right) / (2 * curvature)))


def midpoint_px(a_px: Point, b_px: Point) -> Point:
    """The point halfway between two points.

    Examples
    --------
    >>> midpoint_px((0.0, 0.0), (4.0, 2.0))
    (2.0, 1.0)
    """
    return (a_px[0] + b_px[0]) / 2, (a_px[1] + b_px[1]) / 2


def mirror_point_px(point_px: Point, frame_w_px: float) -> Point:
    """The same point in a left-right mirrored copy of the image.

    Used to draw detections over a mirrored ("selfie") camera view: the image's
    ``[0, frame_w_px]`` span maps onto itself, reversed.

    Parameters
    ----------
    point_px : Point
        ``(x, y)`` in the original image.
    frame_w_px : float
        Image width in pixels.

    Returns
    -------
    Point
        ``(frame_w_px - x, y)``.

    Examples
    --------
    >>> mirror_point_px((100.0, 50.0), 1280)
    (1180.0, 50.0)
    """
    return frame_w_px - point_px[0], point_px[1]


def _normalised(nx: float, ny: float, rho: float) -> Line:
    """The same line, with its normal's larger component positive (+x or +y facing).

    This gives every line one canonical form, so near-duplicates can be compared.
    """
    if (abs(nx) >= abs(ny) and nx < 0) or (abs(ny) > abs(nx) and ny < 0):
        return -nx, -ny, -rho
    return nx, ny, rho


def line_from_polar_px(rho: float, theta_rad: float, origin_px: Point = (0.0, 0.0)) -> Line:
    """A normalised line from an OpenCV Hough ``(rho, theta)`` result.

    Parameters
    ----------
    rho : float
        Distance of the line from the region's origin, in pixels.
    theta_rad : float
        Angle of the line's normal, in radians.
    origin_px : Point, optional
        Where the searched region's top-left corner sits in the full frame, so the
        line can be moved into full-frame coordinates.

    Returns
    -------
    Line
        The line in full-frame ``(nx, ny, rho)`` form.

    Examples
    --------
    >>> line_from_polar_px(10.0, 0.0, origin_px=(5.0, 0.0))  # x = 10 in a region at x = 5
    (1.0, 0.0, 15.0)
    """
    nx, ny = math.cos(theta_rad), math.sin(theta_rad)
    return _normalised(nx, ny, rho + nx * origin_px[0] + ny * origin_px[1])


def line_through_px(point_px: Point, direction: Point, like: Line | None = None) -> Line:
    """The line through a point along a direction.

    Parameters
    ----------
    point_px : Point
        Any point on the line.
    direction : Point
        A vector along the line (any non-zero length).
    like : Line, optional
        If given, the normal is oriented the same way as this line's (useful when
        refining a line, so it keeps its orientation). Otherwise the line is normalised.

    Returns
    -------
    Line
        The line in ``(nx, ny, rho)`` form.

    Raises
    ------
    ValueError
        If ``direction`` is zero or not finite.

    Examples
    --------
    >>> line_through_px((0.0, 4.0), (1.0, 0.0))  # the horizontal line y = 4
    (-0.0, 1.0, 4.0)
    """
    length = math.hypot(*direction)
    if not (math.isfinite(length) and length > 0):
        raise ValueError(f"direction must be a non-zero vector, got {direction!r}")
    nx, ny = -direction[1] / length, direction[0] / length
    line = (nx, ny, nx * point_px[0] + ny * point_px[1])
    if like is None:
        return _normalised(*line)
    if nx * like[0] + ny * like[1] < 0:
        return -line[0], -line[1], -line[2]
    return line


def are_similar_lines(
    a: Line, b: Line, max_angle_deg: float, max_offset_px: float, at_px: Point = (0.0, 0.0)
) -> bool:
    """Whether two normalised lines are close in angle and in position.

    Parameters
    ----------
    a, b : Line
        Normalised lines (see :func:`line_from_polar_px`).
    max_angle_deg : float
        Largest angle between them, in degrees.
    max_offset_px : float
        Largest gap between them near ``at_px``, in pixels.
    at_px : Point, optional
        Where to measure the gap. Use a point where the lines matter (for example the
        middle of the search region): lines at slightly different angles drift apart
        far from where they cross.

    Returns
    -------
    bool
        True if both limits are met.
    """
    cos_angle = max(-1.0, min(1.0, a[0] * b[0] + a[1] * b[1]))
    if math.degrees(math.acos(cos_angle)) > max_angle_deg:
        return False
    return line_gap_px(a, b, at_px) <= max_offset_px


def line_gap_px(a: Line, b: Line, at_px: Point) -> float:
    """Distance between two roughly parallel normalised lines, measured near a point.

    Parameters
    ----------
    a, b : Line
        Normalised, roughly parallel lines.
    at_px : Point
        Where to measure.

    Returns
    -------
    float
        Gap in pixels.

    Examples
    --------
    >>> line_gap_px((0.0, 1.0, 10.0), (0.0, 1.0, 25.0), (0.0, 0.0))
    15.0
    """
    offset_a = a[0] * at_px[0] + a[1] * at_px[1] - a[2]
    offset_b = b[0] * at_px[0] + b[1] * at_px[1] - b[2]
    return abs(offset_a - offset_b)


def side_sample_points_px(a_px: Point, b_px: Point, count: int, inset: float = 0.1) -> list[Point]:
    """Evenly spaced points along a segment, skipping its ends.

    Parameters
    ----------
    a_px, b_px : Point
        Segment end points.
    count : int
        Number of points, at least 2.
    inset : float, optional
        Fraction of the length skipped at each end (corners are often rounded or
        hidden by fingers). Default 0.1.

    Returns
    -------
    list of Point
        ``count`` points from near ``a_px`` to near ``b_px``.

    Raises
    ------
    ValueError
        If ``count < 2``.

    Examples
    --------
    >>> side_sample_points_px((0.0, 0.0), (10.0, 0.0), 2, inset=0.1)
    [(1.0, 0.0), (9.0, 0.0)]
    """
    if count < 2:
        raise ValueError(f"count must be at least 2, got {count}")
    step = (1 - 2 * inset) / (count - 1)
    return [
        (
            a_px[0] + (inset + k * step) * (b_px[0] - a_px[0]),
            a_px[1] + (inset + k * step) * (b_px[1] - a_px[1]),
        )
        for k in range(count)
    ]


def normal_profile_points_px(point_px: Point, line: Line, reach_px: int) -> list[Point]:
    """Points crossing a line at right angles, one pixel apart.

    Used to sample image brightness across an edge to find it to sub-pixel accuracy.

    Parameters
    ----------
    point_px : Point
        Where to cross the line.
    line : Line
        The line; its unit normal gives the crossing direction.
    reach_px : int
        How far to go either side.

    Returns
    -------
    list of Point
        ``2 * reach_px + 1`` points from ``-reach_px`` to ``+reach_px`` along the normal.

    Examples
    --------
    >>> normal_profile_points_px((5.0, 5.0), (0.0, 1.0, 5.0), 1)
    [(5.0, 4.0), (5.0, 5.0), (5.0, 6.0)]
    """
    return [
        (point_px[0] + t * line[0], point_px[1] + t * line[1])
        for t in range(-reach_px, reach_px + 1)
    ]


def segment_extensions_px(
    a_px: Point, b_px: Point, length_px: float
) -> tuple[tuple[Point, Point], tuple[Point, Point]]:
    """The stretches of a segment's line just beyond each of its ends.

    Used to check whether an edge carries on past a candidate corner, which suggests
    the candidate is a printed rectangle on the card rather than the card itself.

    Parameters
    ----------
    a_px, b_px : Point
        Segment end points (must differ).
    length_px : float
        How far to extend past each end.

    Returns
    -------
    tuple
        ``((a_out, a), (b, b_out))``: the extension before ``a`` and the one after ``b``.

    Raises
    ------
    ValueError
        If the two points are the same.

    Examples
    --------
    >>> segment_extensions_px((0.0, 0.0), (10.0, 0.0), 2.0)
    (((-2.0, 0.0), (0.0, 0.0)), ((10.0, 0.0), (12.0, 0.0)))
    """
    length = pixel_distance_px(a_px, b_px)
    _require_positive(segment_length_px=length)
    ux, uy = (b_px[0] - a_px[0]) / length, (b_px[1] - a_px[1]) / length
    a_out = (a_px[0] - ux * length_px, a_px[1] - uy * length_px)
    b_out = (b_px[0] + ux * length_px, b_px[1] + uy * length_px)
    return (a_out, a_px), (b_px, b_out)


def card_gap_limits_px(
    frame_w_px: float, ipd_px: float | None = None
) -> tuple[tuple[float, float], tuple[float, float]]:
    """Generous size limits for a card, for discarding line pairs early.

    Parameters
    ----------
    frame_w_px : float
        Camera frame width in pixels.
    ipd_px : float, optional
        Pupil distance in pixels, if eyes were found. This narrows the limits to
        cards held next to those eyes.

    Returns
    -------
    tuple
        ``((min, max) gap between the card's short sides, (min, max) gap between its
        long sides)``, in pixels, with 10% slack. The exact checks happen later in
        :func:`is_plausible_card_quad`.
    """
    if ipd_px is None:
        w_lo, w_hi = 0.9 * CARD_MIN_WIDTH_FRACTION * frame_w_px, float(frame_w_px)
    else:
        w_lo, w_hi = 0.9 * CARD_TO_IPD_RANGE[0] * ipd_px, 1.1 * CARD_TO_IPD_RANGE[1] * ipd_px
    return (w_lo, w_hi), (w_lo / CARD_TILT_ASPECT_RANGE[1], w_hi / CARD_TILT_ASPECT_RANGE[0])
