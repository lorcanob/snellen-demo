"""Allow ``python -m snellen`` to run the app; see :func:`snellen.main`."""

from snellen import main

if __name__ == "__main__":
    main()
