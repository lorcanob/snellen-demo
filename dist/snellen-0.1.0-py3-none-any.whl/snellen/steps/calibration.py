"""Camera calibration step: the logic behind :mod:`snellen.camera_screen`, with no pygame.

The user sits a known distance from the camera (:data:`CALIBRATION_DISTANCE_MM`, six card
lengths) with a bank card held flat against their forehead. The step collects
:data:`CALIBRATION_FRAMES` frames in which both the card and the eyes are seen, then
:func:`snellen.geometry.calibrate` turns them into the camera's focal length, the user's
pupil distance, and the one-eye face spans used while an eye is covered.

This is a screening toy, not a diagnostic tool.
"""

from enum import Enum, auto

from snellen.geometry import (
    CALIBRATION_DISTANCE_MM,
    CREDIT_CARD_WIDTH_MM,
    Calibration,
    Eye,
    calibrate,
)
from snellen.measurements import Reading
from snellen.steps import DISCLAIMER

CALIBRATION_FRAMES = 30
"""Frames with both card and eyes visible needed to calibrate (about 1 s)."""

NO_FRAME_LIMIT = 90
"""Consecutive frames with no camera picture before calibration fails (about 3 s)."""

HINT_AFTER_FRAMES = 300
"""Camera frames seen before showing tips for whatever is rarely detected (about 10 s)."""

SPAN_FIELDS = ("left_nose_px", "right_nose_px", "left_iris_px", "right_iris_px")
"""Reading fields collected for one-eye ranging (keyword names of geometry.calibrate)."""

CARD_HINT = "Card tips: plain background behind it, hold it by the edges, all four corners visible."
EYES_HINT = "Eye tips: face the camera in good light, avoid glare on glasses."
"""Tips shown while collecting when the card or the eyes are found in under half the frames."""


class Phase(Enum):
    """Where the calibration screen is.

    Attributes
    ----------
    INSTRUCT
        Showing instructions; the camera isn't read yet.
    COLLECTING
        Collecting frames.
    DONE
        Calibrated; showing the user's pupil distance.
    FAILED
        Something went wrong; showing why, with an option to retry.
    """

    INSTRUCT = auto()
    COLLECTING = auto()
    DONE = auto()
    FAILED = auto()


class CalibrationStep:
    """State of the calibration screen, with no pygame, so it can be tested directly.

    Call :meth:`advance` when the user presses SPACE, :meth:`feed` with each tracker reading
    while collecting, and :meth:`lines` to get the text to show.

    Parameters
    ----------
    distance_mm : float, optional
        Eye-to-camera distance the user is asked to sit at. Default
        :data:`snellen.geometry.CALIBRATION_DISTANCE_MM`.
    frames_needed : int, optional
        Frames with both card and eyes visible needed to calibrate. Default
        :data:`CALIBRATION_FRAMES`.

    Attributes
    ----------
    phase : Phase
        Current phase.
    result : Calibration or None
        The calibration, once :attr:`phase` is ``DONE``.
    finished : bool
        True once the user has acknowledged the result; the loop then returns.
    """

    def __init__(
        self,
        distance_mm: float = CALIBRATION_DISTANCE_MM,
        frames_needed: int = CALIBRATION_FRAMES,
    ) -> None:
        """Start on the instructions with nothing collected.

        See the class docstring for the parameters.
        """
        self.distance_mm = distance_mm
        self.frames_needed = frames_needed
        self.phase = Phase.INSTRUCT
        self.result: Calibration | None = None
        self.finished = False
        self._card_px: list[float] = []
        self._ipd_px: list[float] = []
        self._spans_px: dict[str, list[float]] = {name: [] for name in SPAN_FIELDS}
        self._error = ""
        self._reset_counts()

    def _reset_counts(self) -> None:
        """Forget all collected frames and detection counts (on start and on retry)."""
        self._card_px.clear()
        self._ipd_px.clear()
        for values in self._spans_px.values():
            values.clear()
        self._frames_seen = 0
        self._card_seen = 0
        self._eyes_seen = 0
        self._no_picture_run = 0

    @property
    def frames_collected(self) -> int:
        """int: Frames collected so far with both the card and the eyes visible."""
        return len(self._card_px)

    def advance(self) -> None:
        """Handle the user's "continue" key (SPACE).

        Starts collecting from the instructions or after a failure, and marks the step finished
        once a result has been shown. Does nothing while collecting.
        """
        if self.phase in (Phase.INSTRUCT, Phase.FAILED):
            self._reset_counts()
            self.phase = Phase.COLLECTING
        elif self.phase is Phase.DONE:
            self.finished = True

    def press(self, key: str) -> None:
        """Handle a key press by name: ``"space"`` continues; other keys are ignored.

        Parameters
        ----------
        key : str
            The key's name, as :func:`snellen.ui.key_name` gives it (``"space"``).
        """
        if key == "space":
            self.advance()

    def feed(self, reading: Reading | None) -> None:
        """Add one tracker reading while collecting, and calibrate once enough are in.

        Parameters
        ----------
        reading : Reading or None
            The latest tracker reading, or ``None`` if the camera gave no picture.

        Notes
        -----
        * Readings are ignored outside the ``COLLECTING`` phase.
        * :data:`NO_FRAME_LIMIT` pictureless frames in a row fail calibration.
        * Only frames with both card and eyes count towards :attr:`frames_needed`; one-eye
          spans are collected from those frames when present.
        * If :func:`snellen.geometry.calibrate` rejects the result (for example an
          implausible pupil distance), the phase becomes ``FAILED`` with its message.
        """
        if self.phase is not Phase.COLLECTING:
            return
        if reading is None:
            self._no_picture_run += 1
            if self._no_picture_run >= NO_FRAME_LIMIT:
                self._error = "the camera stopped sending pictures"
                self.phase = Phase.FAILED
            return
        self._no_picture_run = 0
        self._frames_seen += 1
        self._card_seen += reading.card_width_px is not None
        self._eyes_seen += reading.ipd_px is not None
        if reading.card_width_px is None or reading.ipd_px is None:
            return
        self._card_px.append(reading.card_width_px)
        self._ipd_px.append(reading.ipd_px)
        for name, values in self._spans_px.items():
            span_px = getattr(reading, name)
            if span_px is not None and span_px > 0:
                values.append(span_px)
        if self.frames_collected < self.frames_needed:
            return
        try:
            self.result = calibrate(self._card_px, self._ipd_px, self.distance_mm, **self._spans_px)
            self.phase = Phase.DONE
        except ValueError as e:
            self._error = str(e)
            self.phase = Phase.FAILED

    def lines(self) -> list[str]:
        """Body text for the current phase.

        Returns
        -------
        list of str
            Lines to draw, top to bottom. While collecting, these include how often the card
            and eyes are being detected, plus tips after :data:`HINT_AFTER_FRAMES` frames for
            whichever is rarely seen.
        """
        if self.phase is Phase.INSTRUCT:
            cm = self.distance_mm / 10
            cards = self.distance_mm / CREDIT_CARD_WIDTH_MM
            return [
                f"1. Sit with your eyes {cm:.0f} cm from the camera ({cards:.0f} card lengths).",
                "2. Hold a bank card flat against your forehead, long edge level,",
                "    gripping it by its edges so all four corners show.",
                "3. Look at the camera and press SPACE. Hold still for a second.",
                "",
                "Esc to quit.  " + DISCLAIMER,
            ]
        if self.phase is Phase.COLLECTING:
            lines = [f"Hold still... {self.frames_collected}/{self.frames_needed}"]
            if self._no_picture_run:
                return lines + ["Camera: no picture"]
            seen = self._frames_seen
            lines.append(
                f"Card: seen {self._card_seen}/{seen} frames    "
                f"Eyes: seen {self._eyes_seen}/{seen} frames"
            )
            if seen >= HINT_AFTER_FRAMES:
                # "Rarely" = in under half the frames so far.
                if 2 * self._card_seen < seen:
                    lines.append(CARD_HINT)
                if 2 * self._eyes_seen < seen:
                    lines.append(EYES_HINT)
            return lines
        if self.phase is Phase.DONE:
            assert self.result is not None
            return [
                f"Calibrated. Your pupil distance is about {self.result.ipd_mm:.1f} mm.",
                "One-eye tracking: " + one_eye_summary(self.result),
                "You can put the card away. Press SPACE to continue.",
            ]
        reason = self._error[:1].upper() + self._error[1:]
        return ["Calibration failed.", f"{reason}.", "Press SPACE to try again."]


def one_eye_summary(calibration: Calibration) -> str:
    """Say which eyes can have their distance tracked while the other is covered.

    Parameters
    ----------
    calibration : Calibration
        A finished calibration.

    Returns
    -------
    str
        For example ``"left eye ready, right eye size held while covered."``. An eye is
        ready if at least one of its spans was calibrated.
    """
    parts = []
    for eye in Eye:
        known = any(span is not None for span in calibration.spans_mm(eye))
        parts.append(f"{eye.value} eye {'ready' if known else 'size held while covered'}")
    return ", ".join(parts) + "."
