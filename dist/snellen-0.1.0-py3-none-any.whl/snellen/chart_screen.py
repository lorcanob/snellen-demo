"""Eye test screen for the Snellen screening toy: draws the chart and runs its loop.

The logic (choosing a chart, measuring distance one eye at a time, scoring) is
:class:`snellen.steps.chart.ChartStep`, which has no pygame; see that module for how it
works. This module draws it, with optotypes from :mod:`snellen.optotype_drawing`.

This is a screening toy, not a diagnostic tool.
"""

import random
from collections.abc import Sequence

import pygame

from snellen.acuity import EyeResult
from snellen.geometry import Calibration, Eye
from snellen.measurements import ReadingSource
from snellen.optotype_drawing import Renderer, renderer_for
from snellen.optotypes import Optotype
from snellen.steps.chart import ChartPhase, ChartStep
from snellen.ui import (
    ACCENT,
    BACKGROUND,
    ERROR,
    MUTED,
    TEXT,
    Events,
    Tick,
    draw_text_page,
    frame_clock,
    is_quit,
    key_name,
)


def draw_chart(
    surface: pygame.Surface, step: ChartStep, renderers: dict[str, Renderer] | None = None
) -> None:
    """Render the eye test screen for the step's current phase.

    During the test, the five optotypes of the current line are drawn one letter-width
    apart, a quarter of the way down the screen (close to the camera that distance is
    measured from), with a marker under the one being asked about. If the row is too
    wide for the window, only the current optotype is shown.

    Parameters
    ----------
    surface : pygame.Surface
        Where to draw (usually the window).
    step : ChartStep
        The state to show.
    renderers : dict of str to Renderer, optional
        Renderers by optotype name, filled in as needed. Pass the same dict every frame
        so a letter chart's font is loaded once; by default a new one is made per call.
    """
    if step.phase is not ChartPhase.TESTING:
        lines = step.lines()
        title = "Results" if step.phase is ChartPhase.RESULTS else "Eye test"
        colours = [TEXT] * len(lines)
        if step.phase in (ChartPhase.CHOOSE, ChartPhase.INSTRUCT):
            colours[-1] = MUTED
        else:
            colours[0] = ACCENT
        draw_text_page(surface, title, lines, colours)
        return

    assert step.test is not None and step.optotype is not None
    renderers = {} if renderers is None else renderers
    if step.optotype.name not in renderers:
        renderers[step.optotype.name] = renderer_for(step.optotype)
    renderer = renderers[step.optotype.name]
    surface.fill(BACKGROUND)
    small = pygame.font.Font(None, 26)
    surface.blit(small.render(step.status(), True, MUTED), (16, surface.get_height() - 30))
    warning = step.warning()
    if warning:
        surface.blit(small.render(warning, True, ERROR), (16, 12))

    height_px = step.letter_height_px
    if height_px is None:
        return
    # Near the top so the letters stay close to the camera the distance is measured to.
    centre_y = max(surface.get_height() // 4, round(height_px))
    gap = height_px  # one letter width between optotypes
    row_w = len(step.test.symbols) * (height_px + gap) - gap
    if row_w <= surface.get_width() * 0.95:
        positions = range(len(step.test.symbols))
        left = (surface.get_width() - row_w) / 2
    else:  # too wide: only the one being asked about
        positions = [step.test.position]
        left = (surface.get_width() - height_px) / 2 - step.test.position * (height_px + gap)
    for i in positions:
        glyph = renderer.render(step.test.symbols[i], height_px, TEXT)
        centre_x = left + i * (height_px + gap) + height_px / 2
        surface.blit(glyph, glyph.get_rect(center=(round(centre_x), centre_y)))
        if i == step.test.position:
            marker_y = round(centre_y + height_px)
            half = max(4, round(height_px / 4))
            pygame.draw.line(
                surface, ACCENT, (centre_x - half, marker_y), (centre_x + half, marker_y), 3
            )


def run_chart(
    surface: pygame.Surface,
    tracker: ReadingSource,
    calibration: Calibration,
    px_per_mm: float,
    *,
    rng: random.Random | None = None,
    optotypes: Sequence[Optotype] | None = None,
    get_events: Events = pygame.event.get,
    tick: Tick | None = None,
) -> dict[Eye, EyeResult] | None:
    """Run the eye test until both eyes are done or the user quits.

    Parameters
    ----------
    surface : pygame.Surface
        The window to draw on.
    tracker : ReadingSource
        Source of camera readings; read every frame.
    calibration : Calibration
        The user's camera calibration.
    px_per_mm : float
        Screen pixel density, in window pixels per mm.
    rng : random.Random, optional
        Source of the random optotypes.
    optotypes : sequence of Optotype, optional
        The charts offered; all of :func:`snellen.optotypes.available_optotypes` by
        default.
    get_events : callable, optional
        Returns the pending pygame events; ``pygame.event.get`` by default.
    tick : callable, optional
        Called once per frame to pace the loop; 30 fps by default.

    Returns
    -------
    dict of Eye to EyeResult or None
        Each eye's result, or ``None`` if the user closed the window or pressed Esc.
    """
    tick = frame_clock(tick)
    step = ChartStep(calibration, px_per_mm, rng, optotypes)
    renderers: dict[str, Renderer] = {}
    while True:
        for event in get_events():
            if is_quit(event):
                return None
            if event.type == pygame.KEYDOWN:
                step.press(key_name(event))
        if step.finished:
            return step.results
        step.feed(tracker.read())
        draw_chart(surface, step, renderers)
        pygame.display.flip()
        tick()
