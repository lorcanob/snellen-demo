"""Face measurements from MediaPipe face-mesh landmarks: pupils and one-eye spans.

Works on the landmark list MediaPipe's Face Landmarker gives for one face: 478 points
whose ``x`` and ``y`` are normalised to 0..1 across the image. Any objects with those
attributes will do, so this module needs neither MediaPipe nor OpenCV. In a browser
it can take the JavaScript Face Landmarker's results directly.

"Left" and "right" mean the subject's own eyes.
"""

from snellen.geometry import Point, pixel_distance_px
from snellen.measurements import EyeSpans

LEFT_IRIS_CENTRE = 468
"""Face-mesh landmark at the iris centre on the image's left (subject's right eye on an
unmirrored camera)."""

RIGHT_IRIS_CENTRE = 473
"""Face-mesh landmark at the iris centre on the image's right (subject's left eye)."""

NOSE_BRIDGE = 168
"""Face-mesh landmark on the bridge of the nose, between the eyes; it stays visible
when a hand covers one eye."""

SUBJECT_RIGHT_IRIS = (468, (469, 470, 471, 472))
SUBJECT_LEFT_IRIS = (473, (474, 475, 476, 477))
"""(centre, ring) per subject's eye; each ring runs outer, top, inner, bottom, so
ring[0]-ring[2] is a horizontal diameter and ring[1]-ring[3] a vertical one."""


def pupils_px(landmarks: list, width_px: int, height_px: int) -> tuple[Point, Point] | None:
    """Pixel coordinates of the two iris centres.

    Parameters
    ----------
    landmarks : list
        One face's MediaPipe landmarks, with ``x`` and ``y`` normalised to 0..1.
    width_px, height_px : int
        Frame size.

    Returns
    -------
    tuple of Point or None
        ``(landmark 468, landmark 473)`` in pixels, or ``None`` if the model gave no iris
        landmarks.
    """
    if len(landmarks) <= RIGHT_IRIS_CENTRE:
        return None
    left, right = landmarks[LEFT_IRIS_CENTRE], landmarks[RIGHT_IRIS_CENTRE]
    return (left.x * width_px, left.y * height_px), (right.x * width_px, right.y * height_px)


def eye_spans_px(landmarks: list, width_px: int, height_px: int) -> EyeSpans | None:
    """The one-eye spans for each of the subject's eyes.

    Parameters
    ----------
    landmarks : list
        One face's MediaPipe landmarks (478 with irises), normalised to 0..1.
    width_px, height_px : int
        Frame size.

    Returns
    -------
    EyeSpans or None
        Pupil-to-nose-bridge distance and iris diameter (mean of the horizontal and
        vertical diameters of the iris ring) for each eye, in pixels; ``None`` without
        iris landmarks.
    """
    if len(landmarks) <= max(SUBJECT_LEFT_IRIS[1]):
        return None

    def at(index: int) -> Point:
        """Landmark ``index`` in pixels."""
        return landmarks[index].x * width_px, landmarks[index].y * height_px

    nose = at(NOSE_BRIDGE)

    def nose_and_iris(centre: int, ring: tuple[int, int, int, int]) -> tuple[float, float]:
        """(pupil to nose bridge, iris diameter) in pixels for one eye's landmarks."""
        iris = (
            pixel_distance_px(at(ring[0]), at(ring[2]))
            + pixel_distance_px(at(ring[1]), at(ring[3]))
        ) / 2
        return pixel_distance_px(at(centre), nose), iris

    right_nose, right_iris = nose_and_iris(*SUBJECT_RIGHT_IRIS)
    left_nose, left_iris = nose_and_iris(*SUBJECT_LEFT_IRIS)
    return EyeSpans(
        left_nose_px=left_nose,
        right_nose_px=right_nose,
        left_iris_px=left_iris,
        right_iris_px=right_iris,
    )
