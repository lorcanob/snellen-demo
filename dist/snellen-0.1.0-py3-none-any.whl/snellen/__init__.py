"""Snellen screening toy: a webcam eye test you can run on a laptop.

Not a diagnostic tool. It is a screening toy and doesn't replace an eye examination.

Running ``uv run python -m snellen`` (or the installed ``snellen`` command) goes through
three screens and then prints the results:

1. **Screen size** (:mod:`snellen.screen_size_screen`): confirm the screen's pixel
   density read from the hardware, or measure it by matching a bank card against bars.
2. **Camera calibration** (:mod:`snellen.camera_screen`): hold the card on your
   forehead at a set distance, so the app learns the camera's focal length and the
   sizes of your face.
3. **Eye test** (:mod:`snellen.chart_screen`): a Tumbling-E chart for each eye in
   turn, with letters sized live to your distance from the screen.

Package layout
--------------
geometry
    All the maths (pure functions).
tracker
    Camera and MediaPipe face model; the only module that needs MediaPipe.
card, face, measurements
    Card detection, face-landmark spans and the per-frame results, in pixels.
acuity
    Staircase scoring.
optotypes
    The chart types (Snellen letters, Tumbling E, Landolt C) and their answer keys.
steps
    Each screen's logic as a pygame-free state machine (calibration, screen size,
    chart), so it can also run in a browser.
screen_size
    Hardware screen size and the saved-measurement cache.
camera_screen, screen_size_screen, chart_screen, optotype_drawing, ui
    The pygame front end: screens, optotype drawing and shared helpers.
debug
    Developer camera view (``python -m snellen.debug``).

Environment variables
---------------------
SNELLEN_MODEL_PATH
    Face model file; default ``models/face_landmarker.task``.
SNELLEN_CAMERA_INDEX
    Which camera to use; default 0.
SNELLEN_SCREEN_FILE
    Where screen measurements are saved; default ``~/.config/snellen/screens.json``.
SNELLEN_CAPTURE_DIR
    Where the debug view saves frames; default ``captures/``.
"""

import os
import sys
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from snellen.tracker import Tracker

MODEL_URL = (
    "https://storage.googleapis.com/mediapipe-models/face_landmarker/"
    "face_landmarker/float16/latest/face_landmarker.task"
)
"""Download address of MediaPipe's face landmarker model (with iris landmarks)."""

DEFAULT_MODEL_PATH = "models/face_landmarker.task"
"""Where the face model is looked for unless ``SNELLEN_MODEL_PATH`` says otherwise."""

WINDOW_SIZE_PX = (1280, 720)
"""App window size in window pixels."""


def model_path_or_exit() -> Path:
    """The face model's path, or exit with download instructions if it is missing.

    Returns
    -------
    pathlib.Path
        ``$SNELLEN_MODEL_PATH``, or :data:`DEFAULT_MODEL_PATH` if that isn't set.

    Raises
    ------
    SystemExit
        With status 1 if the file doesn't exist, after printing a ``curl`` command that
        downloads it.
    """
    model_path = Path(os.environ.get("SNELLEN_MODEL_PATH", DEFAULT_MODEL_PATH))
    if not model_path.exists():
        print(
            f"Face model not found at {model_path}. Download it with:\n"
            f"  mkdir -p {model_path.parent} && curl -L -o {model_path} {MODEL_URL}",
            file=sys.stderr,
        )
        sys.exit(1)
    return model_path


def open_tracker_or_exit() -> "Tracker":
    """Open the face model and camera, or exit with advice on how to fix them.

    The camera is opened before any window, so macOS's camera-permission prompt isn't
    hidden behind it.

    Returns
    -------
    Tracker
        A ready tracker for camera ``$SNELLEN_CAMERA_INDEX`` (default 0).

    Raises
    ------
    SystemExit
        With status 1 if the model is missing or the camera gives no picture.
    """
    model_path = model_path_or_exit()

    from snellen.tracker import CameraUnavailable, Tracker

    camera_index = int(os.environ.get("SNELLEN_CAMERA_INDEX", "0"))
    # Open the camera before any window so macOS's permission prompt isn't hidden behind it.
    print("Opening camera... if macOS asks for camera access, click Allow.")
    try:
        return Tracker.open(camera_index, model_path)
    except CameraUnavailable as e:
        print(e, file=sys.stderr)
        sys.exit(1)


def main() -> None:
    """Run the whole app: measure the screen, calibrate the camera, test both eyes.

    Prints the screen density, the calibration and each eye's result (Snellen and logMAR)
    to the terminal. A card measurement of the screen is saved for next time. Closing the
    window or pressing Esc at any point cancels the remaining steps.
    """
    tracker = open_tracker_or_exit()

    import pygame

    from snellen.camera_screen import run_calibration
    from snellen.chart_screen import run_chart
    from snellen.screen_size import (
        ScreenRecord,
        cache_path,
        desktop_key,
        hardware_px_per_mm,
        load_cached,
        save_cached,
    )
    from snellen.screen_size_screen import run_screen_size

    pygame.init()
    results = calibration = screen_record = None
    try:
        screen = pygame.display.set_mode(WINDOW_SIZE_PX)
        pygame.display.set_caption("Snellen screening toy")
        key = desktop_key(pygame.display.get_desktop_sizes()[0])
        known = load_cached(key, cache_path())
        if known is None and (hardware := hardware_px_per_mm()) is not None:
            known = ScreenRecord(hardware, "hardware")
        with tracker:
            screen_record = run_screen_size(screen, known)
            if screen_record is not None:
                if screen_record.source == "card":
                    save_cached(key, screen_record, cache_path())
                calibration = run_calibration(screen, tracker)
            if screen_record is not None and calibration is not None:
                results = run_chart(screen, tracker, calibration, screen_record.px_per_mm)
    except KeyboardInterrupt:
        results = None
    finally:
        pygame.quit()

    if screen_record is not None:
        print(f"Screen: {screen_record.px_per_mm:.2f} px/mm ({screen_record.source}).")
    if calibration is not None:
        print(
            f"Calibrated: focal length {calibration.focal_length_px:.0f} px, "
            f"pupil distance {calibration.ipd_mm:.1f} mm."
        )
    if results is None:
        print("Eye test cancelled.")
        return
    for eye, result in results.items():
        print(f"{eye.value.capitalize()} eye: {result.describe()}")
    print("Screening toy only - not a medical test. See an optometrist about any concerns.")
