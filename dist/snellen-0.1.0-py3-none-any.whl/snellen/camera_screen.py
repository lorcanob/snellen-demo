"""Camera calibration screen for the Snellen screening toy.

The user sits a known distance from the camera (:data:`~snellen.geometry.CALIBRATION_DISTANCE_MM`,
six card lengths) with a bank card held flat against their forehead. The screen collects
:data:`~snellen.steps.calibration.CALIBRATION_FRAMES` frames in which both the card and the eyes are seen. Then
:func:`snellen.geometry.calibrate` turns them into:

* the camera's focal length in pixels,
* the user's pupil distance in mm, and
* the one-eye face spans (pupil to nose bridge, iris) used to measure distance
  while one eye is covered during the test.

The screen's logic is :class:`snellen.steps.calibration.CalibrationStep`, which has no
pygame; this module only draws it (:func:`draw_calibration`) and runs its event loop
(:func:`run_calibration`).

This is a screening toy, not a diagnostic tool.
"""

import pygame

from snellen.geometry import CALIBRATION_DISTANCE_MM, Calibration
from snellen.measurements import ReadingSource
from snellen.steps.calibration import CalibrationStep, Phase
from snellen.ui import (
    ACCENT,
    ERROR,
    MUTED,
    TEXT,
    Events,
    Tick,
    draw_text_page,
    frame_clock,
    is_quit,
    key_name,
)


def draw_calibration(surface: pygame.Surface, step: CalibrationStep) -> None:
    """Render the calibration screen for the step's current phase.

    Parameters
    ----------
    surface : pygame.Surface
        Where to draw (usually the window).
    step : CalibrationStep
        The state to show. While collecting, a progress bar is drawn under the text.
    """
    lines = step.lines()
    if step.phase is Phase.INSTRUCT:
        colours = [TEXT] * (len(lines) - 1) + [MUTED]  # steps, then the Esc/disclaimer line
    else:
        headline = {Phase.DONE: ACCENT, Phase.FAILED: ERROR}.get(step.phase, TEXT)
        colours = [headline] + [MUTED] * (len(lines) - 1)
    y = draw_text_page(surface, "Camera calibration", lines, colours)
    margin = surface.get_width() // 12

    if step.phase is Phase.COLLECTING:
        bar = pygame.Rect(margin, y + 20, surface.get_width() - 2 * margin, 16)
        filled = bar.copy()
        filled.width = bar.width * step.frames_collected // step.frames_needed
        pygame.draw.rect(surface, MUTED, bar, width=1)
        pygame.draw.rect(surface, ACCENT, filled)


def run_calibration(
    surface: pygame.Surface,
    tracker: ReadingSource,
    distance_mm: float = CALIBRATION_DISTANCE_MM,
    *,
    get_events: Events = pygame.event.get,
    tick: Tick | None = None,
) -> Calibration | None:
    """Run the calibration screen until it is done or the user quits.

    Parameters
    ----------
    surface : pygame.Surface
        The window to draw on.
    tracker : ReadingSource
        Source of camera readings; only read while collecting.
    distance_mm : float, optional
        Eye-to-camera distance the user is asked to sit at.
    get_events : callable, optional
        Returns the pending pygame events; ``pygame.event.get`` by default (tests pass a
        scripted list).
    tick : callable, optional
        Called once per frame to pace the loop; by default it holds the loop to 30 fps.

    Returns
    -------
    Calibration or None
        The calibration, or ``None`` if the user closed the window or pressed Esc.
    """
    tick = frame_clock(tick)
    step = CalibrationStep(distance_mm)
    while True:
        for event in get_events():
            if is_quit(event):
                return None
            if event.type == pygame.KEYDOWN:
                step.press(key_name(event))
        if step.finished:
            return step.result
        if step.phase is Phase.COLLECTING:
            step.feed(tracker.read())
        draw_calibration(surface, step)
        pygame.display.flip()
        tick()
